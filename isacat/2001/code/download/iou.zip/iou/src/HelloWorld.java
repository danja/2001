

public class HelloWorld {
    public String sayHello() {
        return "Hello World";
    }
}

