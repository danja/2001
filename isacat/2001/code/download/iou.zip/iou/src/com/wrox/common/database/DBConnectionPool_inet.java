package com.wrox.common.database;
/*
 * note - for some reason there is a dependency on the JTA API from the
 * inet classes - the JTA classes
 * need to be in the classpath for this file to compile
 */

import java.util.*;
import java.sql.*;
import java.io.*;
import java.beans.*;

import javax.sql.*;

import com.inet.pool.*;

import com.wrox.common.util.*;


/**
 *
 *@author     Danny Ayers 
 *@created    10 November 2000 
 */
public class DBConnectionPool_inet implements Serializable {

    private boolean debug = true;
	private PropertyChangeSupport changesupport;
	private Properties properties;

        private com.inet.pool.PoolManager manager;
        DataSource ds = null;
        com.inet.pool.PDataSource pds = null;
        
	private static PrintStream log = System.out;
	private String database;
	private String user;

        private String catalog;
	private String password;
	private int timeout;



	/**
	 */
	public DBConnectionPool_inet(Properties prop) {
             manager = new com.inet.pool.PoolManager();
             debug("pool manager = "+manager);
             debug("properties = "+prop);
		properties = prop;
		changesupport = new PropertyChangeSupport(this);
		database = properties.getProperty("pool.database");
                catalog = properties.getProperty("pool.catalog");
		user = properties.getProperty("pool.user");
		password = properties.getProperty("pool.password");
		timeout = Integer.parseInt(properties.getProperty("pool.timeout"));
                
		prepareConnections();		// throws SQLException   
	}


	/**
	 *  Sets the Log attribute of the ConnectionPool object 
	 *
	 *@param  ps  The new Log value 
	 */
	public void setLog(LogPrinter lp) {
		log = lp;
	}


	/**
	 *  Gets the Connection attribute of the ConnectionPool object 
	 *
	 *@return    The Connection value 
	 */
	public synchronized Connection getConnection() {
            Connection con = null;
          //  PoolManager pm = PoolManager.getDefault();
            try{
                con = manager.getConnection( ds );
            } catch (Exception e){
                 e.printStackTrace();
                }
	    return con;
	}


	/**
	 *  Gets the AvailableConnections attribute of the ConnectionPool object 
	 *
	 *@return    The AvailableConnections value 
	 */
	public int getAvailableConnections() {
		return manager.getFreeConnectionCount();
	}


	/**
	 *  Gets the Status attribute of the ConnectionPool object 
	 *
	 *@return    The Status value 
	 */
	public String getStatus() {
            String status = "Pool Count:"+manager.getConnectionCount()
                        +"  Free:"+manager.getFreeConnectionCount()
                        +"  Used:"+manager.getUsedConnectionCount();
		return status;
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	public synchronized boolean prepareConnections() {
            try{
                // init the PoolManager with your default values
                manager = PoolManager.getDefault();
                manager.setMaxConnectionCount(2);
            
                // create a ConnectionPoolDataSource for the PoolManager
                // and save it in a global variable for later use
                debug("manager "+manager);
                pds = new com.inet.pool.PDataSource();
                debug("pds = "+pds);
                pds.setServerName(database);
                pds.setDatabaseName(catalog);
                pds.setUser(user);
                pds.setPassword(password);
                System.out.println("timeout = "+timeout);
                pds.setLoginTimeout(timeout);
              
                pds.setDescription( "Pool Data Source" );
                ds = pds;
                ////////////////////
                		    //open a connection to the database
		    Connection connection = ds.getConnection("kane","citizen");

		    //to get the driver version
	            DatabaseMetaData conMD = connection.getMetaData();
	            System.out.println("Driver Name:   \t" + conMD.getDriverName());
	            System.out.println("Driver Version:\t" + conMD.getDriverVersion());
	             connection.close();
	            //////////////////////////////
                
                debug("ds = "+ds);
            }catch(Exception e){
                e.printStackTrace();
                }    
                return true;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  conn  Description of Parameter 
	 */
	public synchronized void returnConnection(Connection conn) {
            try{
                conn.close();
            }catch(Exception e){
                e.printStackTrace();
                }  
        }


	/**
	 *  Description of the Method 
	 *
	 *@param  conn    Description of Parameter 
	 *@param  millis  Description of Parameter 
	 */
	public synchronized void keepAlive(Connection conn, int millis) {
	}


	/**
	 *  Description of the Method 
	 *
	 *@exception  SQLException  Description of Exception 
	 */
	public synchronized void closeAll() throws SQLException {

	}


	/**
	 *  Description of the Method 
	 */
	public void shutdown() {
	}


	/**
	 *  Adds a feature to the PropertyChangeListener attribute of the 
	 *  ConnectionPool object 
	 *
	 *@param  listener  The feature to be added to the PropertyChangeListener 
	 *      attribute 
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		changesupport.addPropertyChangeListener(listener);
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  listener  Description of Parameter 
	 */
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		changesupport.removePropertyChangeListener(listener);
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	private synchronized Connection obtainConnection() {
            Connection con = null;
            try{   
                con = manager.getConnection( ds );
            } catch (Exception e) {
                e.printStackTrace();
                }
    	    return con;
	}
        
        private void debug(Object ob){
            if(debug) System.out.println(ob);
        }
}

