/*
 * DBAccess.java
 *
 * Created on 04 December 2000, 17:57
 */

package com.wrox.iou.database;

import java.util.*;
import java.sql.*;
import java.io.*;

import com.wrox.common.database.*;
import com.wrox.common.util.*;
import com.wrox.iou.page.*;
/**
 * @author     Danny Ayers
 * @created    10 February 2001
 * @version
 */
public class FilteredDBAccess extends DBAccess {

  int rawCount = 0;
  int recordCount = -1;

  private PrintStream log = System.out;

// private ArrayList docs = new ArrayList();

  //  private static final int toDBSize = 1; //50?

  private final static String FILTERED_TABLE = "core";

  /**
   *  Creates new DBAccess
   */
  public FilteredDBAccess() {
    // docs = new Document[toDBSize];
  }


  public int getRecordCount() {

    if (recordCount == -1) {
      Connection conn = pool.getConnection();
      recordCount = DBUtils.countRecords(conn, FILTERED_TABLE);
      pool.returnConnection(conn);
    }
    return recordCount;
  }

  public void store(ArrayList docs) {
    // System.out.println("commit raw");
    Connection conn = pool.getConnection();

    //     System.out.println("conn = "+conn);
    PreparedStatement storeraw = null;
    try {
      storeraw = conn.prepareStatement("INSERT INTO " + FILTERED_TABLE + " (ID, COREWORDS) VALUES (?,?)");
    } catch (Exception e) {
      log.println("error preparing filter store statement : " + e);
    }
    for (int i = 0; i < docs.size(); i++) {
      recordCount++;
      FilteredDocument rd = (FilteredDocument) docs.get(i);
      HyperLink rdlink = rd.getLink();
      try {
        storeraw.setInt(1, rd.getID());
        storeraw.setString(2, rd.getCorewords());
      } catch (Exception e) {
        log.println("error setting filter store statement : " + e);
      }
      try {
        storeraw.executeUpdate();
        rd.setID(recordCount);
      } catch (Exception e) {
        log.println("error executing filter store statement : " + e);
      }
    }
    docs.clear();
    pool.returnConnection(conn);
  }
}
