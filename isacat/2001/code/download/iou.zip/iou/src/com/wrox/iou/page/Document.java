/*
 * Document.java
 *
 * Created on November 30, 2000, 7:26 PM
 */

package com.wrox.iou.page;

import java.beans.*;
import java.util.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import javax.swing.text.html.parser.*;

import com.wrox.iou.filter.*;
/**
 * @author     root
 * @created    09 February 2001
 * @version
 */
public class Document extends HashMap {
  // -1;
  /**
   *  Description of the Field
   */
  public boolean loaded = false;
  /**
   *  Description of the Field
   */
  public boolean html = false;

  private int id = -1;

  private HyperLink hyperlink = null;
  private URL url = null;
  private long pagedate = -1;
  private long expiration = -1;
  private long scandate = -1;
  private int responseCode = 0;
  private String pagetype = null;
  private String content = null;
  private int length = 0;
  private ArrayList links = null;
  private ArrayList linkslist = null;

  private PropertyChangeSupport change;
  private static int MAXLENGTH = 50000;

  private static PrintStream log = System.out;


  public Document() {
//    change = new PropertyChangeSupport(this);
  }


  public void setLog(PrintStream ps) {
    log = ps;
  }


  public void setID(int i) {
    id = i;
  }


  public void setAddress(String s) {
    hyperlink = new HyperLink();
    hyperlink.setAbsolute(s);
  }

  public void setLink(HyperLink h) {
    hyperlink = h;
    url = hyperlink.getURL();
  }

  public void setType(String s) {
    pagetype = s;
  }


  public void setField(String name, Object field) {
    put(name, field);
  }

  public void setFilter(Filter f) {
  }

  public int getID() {
    return id;
  }

  public String getAddress() {
    return hyperlink.getURL().toString();
  }

  public HyperLink getLink() {
    return hyperlink;
  }

  public String getType() {
    return pagetype;
  }

  public Object getField(String name) {
    return get(name);
  }


  public java.sql.Date getPageDate() {
    return new java.sql.Date(pagedate);
  }

  public java.sql.Date getExpiryDate() {
    return new java.sql.Date(expiration);
  }


  public java.sql.Date getScanDate() {
    return new java.sql.Date(scandate);
  }

  public int getResponseCode() {
    return responseCode;
  }

  public String getContent() {
    return content;
  }

  public boolean isAcceptable() {
    return getType().startsWith("text");
  }

  public ArrayList getLinks() {
    return linkslist;
  }

  public boolean read(boolean contentRequired) {
    // load
    scandate = System.currentTimeMillis();
    clear();
    try {
      //currenturl = // new URL(urlstring);
      // urlstring = currenturl.toString();
      // removes /../ from URL

      if (url.getProtocol().equals("http")) {

        //	status = url.getProtocol() + " protocol";

        URLConnection conn = url.openConnection();
        HttpURLConnection httpconn = (HttpURLConnection) conn;
        responseCode = httpconn.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
          pagetype = httpconn.getContentType();
          hyperlink.setType(pagetype);
          if (pagetype.equals("text/plain") || pagetype.equals("text/html")) {

            pagedate = httpconn.getLastModified();
            if (pagedate == 0) {
              pagedate = httpconn.getDate();
            }
            expiration = httpconn.getExpiration();
            length = httpconn.getContentLength();
            length = length > MAXLENGTH ? MAXLENGTH : length;
            html = true;

            log.println("Parsing...");
            InputStreamReader isr = new InputStreamReader(conn.getInputStream());
            BufferedReader in = new BufferedReader(isr);
            if (contentRequired) {
              in.mark(length);
              char[] chars = new char[length];
              in.read(chars, 0, length);
              in.reset();
              content = new String(chars);
              chars = null;
            }
            ParserDelegator pd = new ParserDelegator();
            HTMLParserCallback parsercallback = new HTMLParserCallback();
            try {
              pd.parse(in, parsercallback, true);
            } catch (Exception e) {
              e.printStackTrace();
            }
            putAll(parsercallback.getFields());

            in.close();
            isr.close();
            httpconn.disconnect();


          } else {
            html = false;
            return false;
          }

        } else {
          return false;
        }
      } else {
        html = false;
        return false;
      }

    } catch (Exception e) {
      log.println(e);
      // Mark as a bad URL
    }

    return true;
  }

  public void resolveFields() {
  }

  public void resolveLinks() {
    linkslist = new ArrayList();

    Object linksArray = getField("links");

    String linkpath = getLink().getAbsolutePath();
    HyperLink inlink;
    // a link found in this doc
    linkslist.clear();
    if (linksArray != null) {
      links = (ArrayList) linksArray;
      for (int i = 0; i < links.size(); i++) {
        inlink = (HyperLink) links.get(i);
        if (inlink.getAbsolutePath() == null) {
          // the href must have been relative
          inlink.setAbsolutePath(linkpath);
        }
        // resolve the address with that of the containing doc

        if ((inlink != null)) {
          // && (linktext != null)
          linkslist.add(i, inlink);
        }
      }
    }
  }
}
