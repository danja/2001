/*
 * DBAccess.java
 *
 * Created on 04 December 2000, 17:57
 */

package com.wrox.iou.database;

import java.util.*;
import java.sql.*;
import java.io.*;

import com.wrox.common.database.*;
import com.wrox.common.util.*;
import com.wrox.iou.page.*;
/**
 * @author     Danny Ayers
 * @created    10 February 2001
 * @version
 */
public class DocumentBuffer extends DBBuffer {

// RawDBAccess rawdb = new RawDBAccess();
  int rawCount = 0;
//  int rawEntries = -1;
  int toDBSize = 10;

  private PrintStream log = System.out;

  private ArrayList docs = new ArrayList();


  public DocumentBuffer() {
  }


  public int getRecordCount() {
    return dbaccess.getRecordCount();
  }

  public void save(Document doc) {
    docs.add(doc);
    if (++rawCount == toDBSize) {
      flush();
    }
  }

  public void flush() {
    dbaccess.store(docs);
    rawCount = 0;
  }
}
