/*
 * PropertiesLoader.java
 *
 * Created on 01 December 2000, 20:30
 */

import java.util.*;

/**
 *
 * @author  Danny Ayers
 * @version 
 */
public class SetTestProperties {


    public static Properties getPoolProperties() {
		Properties properties = new Properties();
		properties.setProperty("pool.database", "jdbc:mysql://localhost:3306/iou");
		properties.setProperty("pool.driver", "org.gjt.mm.mysql.Driver");
		properties.setProperty("pool.user", "wrox");
		properties.setProperty("pool.password", "xorw");
		properties.setProperty("pool.size", "10");
		properties.setProperty("pool.timeout", "10");
		return properties;
    }
}
