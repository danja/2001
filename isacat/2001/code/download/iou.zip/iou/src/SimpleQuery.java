

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;


import com.wrox.common.util.*;
import com.wrox.common.database.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    12 February 2001
 */
public class SimpleQuery extends HttpServlet {

  DBConnectionPool pool;

  public SimpleQuery() {

    pool = new DBConnectionPool(getPoolProperties());
  }


  public String getServletInfo() {
    return "SimpleQuery Servlet";
  }

  public ArrayList getMatches(String query) {
    ArrayList results = new ArrayList();
    Statement stmt = null;
    ResultSet rs = null;
    Connection conn = pool.getConnection();
   // String sql = new String("SELECT id FROM CORE WHERE (corewords LIKE '%" + query + "%')");
   // SELECT links.* FROM core LEFT JOIN links ON core.ID = links.docref WHERE (core.corewords LIKE '%game%')

    String sql = new String("SELECT links.* FROM core LEFT JOIN links ON core.id = links.docref WHERE (corewords LIKE '%" + query + "%')");    
    ArrayList hitlist = new ArrayList();

    try {
          stmt = conn.createStatement();
      rs = stmt.executeQuery(sql);
   String link;
   
      while (rs.next()) {
      link = "http://"+rs.getString("host")+"/"+rs.getString("path")+"/"+rs.getString("filename");
      link = "<A HREF="+link+">"+link+"</A>";
        results.add(link);
      }
    } catch (SQLException sqle) {
      System.out.println(sqle.toString());
    }
    pool.returnConnection(conn);



    	return results;
  }

  public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

    // set header field first
    res.setContentType("text/html");

    // Get client's query data
    Enumeration values = req.getParameterNames();
    String name = (String) values.nextElement();
    String query = req.getParameterValues(name)[0];
   // getMatches(query);

    PrintWriter out = res.getWriter();
    out.println("<HEAD><TITLE> Search</TITLE></HEAD><BODY>");
    out.println("<H2> Search Results </H2>");
    out.println("<P>");
    ArrayList results = getMatches(query);
        Object key;
    for (int i = 0;i<results.size();i++) {
      out.println("<br>"+results.get(i)+"<br>");
    }
    /*
    for (Enumeration e = db.getHits().elements(); e.hasMoreElements(); ) {
      out.println(e.nextElement());
    }*/

    out.println("<P>");
    out.println("<FORM ACTION=http://localhost:8080/examples/servlet/SimpleQuery METHOD=POST>");
    out.println("<b><p>New Search :<b>");
    out.println("<INPUT TYPE=text NAME=query SIZE=50> <INPUT TYPE=submit>");
    out.println("</p></form>");
    out.println("</BODY>");
    out.close();
  }
    public Properties getPoolProperties() {
		Properties properties = new Properties();
		properties.setProperty("pool.database", "jdbc:mysql://localhost:3306/iou");
		properties.setProperty("pool.driver", "org.gjt.mm.mysql.Driver");
		properties.setProperty("pool.user", "wrox");
		properties.setProperty("pool.password", "xorw");
		properties.setProperty("pool.size", "10");
		properties.setProperty("pool.timeout", "10");
		return properties;
    }
}

