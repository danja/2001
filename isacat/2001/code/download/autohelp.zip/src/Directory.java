import java.util.*;
import java.io.*;
import java.text.*;

/**
 *  Model of file system directory 
 *
 *@author     Danny Ayers 
 *@created    04 January 2001 
 */
public class Directory {
	boolean isNull;
	String path = "";
	ArrayList dirArray = new ArrayList();
	String endDir = "";
	int ndirs = 0;
	int baselength = 0;


	/**
	 *  Constructor for the Directory object 
	 */
	public Directory() {
		isNull = true;
	}


	/**
	 *  Constructor for the Directory object 
	 *
	 *@param  file     file & directory supplied 
	 *@param  basedir  base directory to which file is appended 
	 */
	public Directory(File file, File basedir) {

		baselength = (basedir.toString()).length();

		path = file.getPath().substring(baselength);

		// make slashes uniform
		path = path.replace('\\', '/');

		// make array of subdirectories
		StringTokenizer st = new StringTokenizer(path, "/");
		String dir;
		while (st.hasMoreTokens()) {
			dir = st.nextToken();
			dirArray.add(dir);
		}
		ndirs = dirArray.size();
		isNull = false;
	}


	/**
	 *  Gets the Depth attribute of the Directory object 
	 *
	 *@return    How many subdirectories? 
	 */
	public int getDepth() {
		return ndirs;
	}


	/*
	 * public String getEndDir() {
	 * if (ndirs == 0) return "root is a dummy"; // to avoid null pointers
	 * return (String) dirArray.get(ndirs - 1);
	 * }
	 */

	/**
	 *  Gets the directory back as an array 
	 *
	 *@return    array of subdirectories 
	 */
	public ArrayList getDirArray() {
		return dirArray;
	}


	/**
	 *  Finds the difference between subdirectories 
	 *
	 *@param  dir  sent directory 
	 *@return      mismatch between directories 
	 */
	public int getMismatch(Directory dir) {
		// how many levels to take off sent dir to get down to common level?
		if (dir == null) {
			return 0;
		}
		if (isNull) {
			return dir.getDepth();
		}
		ArrayList al = dir.getDirArray();
		int sentsize = al.size();
		int min = sentsize < ndirs ? sentsize : ndirs;
		int match;
		for (match = 0; match < min; match++) {
			if (!al.get(match).equals(dirArray.get(match))) {
				break;
			}
		}
		return sentsize - match;
	}


	/**
	 *  Gets the Mismatch attribute of the Directory object 
	 *
	 *@param  dir  Description of Parameter 
	 *@return      The Mismatch value 
	 */
	public boolean isMismatch(Directory dir) {
		return (getMismatch(dir) != 0);
	}


	///////////////////// Utility methods
	/**
	 *  Gets the Url attribute of the Directory object 
	 *
	 *@param  filename  Description of Parameter 
	 *@return           The Url value 
	 */
	public String getUrl(String filename) {
		String url = toString() + "/" + filename;
		//
		// trim leading '/'
		if (url.startsWith("/")) {
			url = url.substring(1, url.length());
		}
		return url;
	}


	/**
	 *  Gets the last subdirectory of the Directory object 
	 *
	 *@return    ../subdir/subdir/endDir 
	 */

	public String makeNameFromDir() {
		if (ndirs == 0) {
			return "root is a dummy";
		}
		// to avoid null pointers
		String rawdirname = (String) dirArray.get(ndirs - 1);
		return clean(tidyCase(rawdirname));
	}


	/**
	 *  Gives a String representation of the path 
	 *
	 *@return    path as String 
	 */
	public String toString() {
		if (path == null) {
			return null;
		}
		String string = path.toString();

		return string;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  filename  Description of Parameter 
	 *@return           Description of the Returned Value 
	 */
	public String makeNameFromFile(String filename) {
		// create a text entry for the index
		// start with the 'humanised' filename
		String name = tidyCase(trimFileExt(filename));

		// if the filename without ext is 'Index'
		if ("Index".equals(name) && (ndirs > 0)) {
			//dirSize
			// use the name of the containing directory
			name = (String) getDirArray().get(ndirs - 1);
			//dirSize
			name = tidyCase(clean(name));
		}
		return name;
	}


	/**
	 *  Gets the RequiredFile attribute of the Directory class 
	 *
	 *@param  s  Description of Parameter 
	 *@return    The RequiredFile value 
	 */
	public static boolean isRequiredFile(String s) {
		if (s.endsWith(".htm") || s.endsWith(".html") || s.endsWith(".txt") || s.endsWith(".java")) {
			return true;
		}
		return false;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  s  Description of Parameter 
	 *@return    Description of the Returned Value 
	 */
	public static String tidyCase(String s) {
		// makes string more human-readable
		if (s == null) {
			return s;
		}
		if (s.length() == 0) {
			return s;
		}

		// first character upper case
		String tidy = s.substring(0, 1).toUpperCase();

		// rest of characters left untouched
		if (s.length() > 1) {
			tidy += s.substring(1, s.length());
		}
		return tidy;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  s         Description of Parameter 
	 *@return           DOM compatible String 
	 */
	public static String clean(String s) {
		//, boolean numerate
		// converts illegal DOM characters into underscores
		StringBuffer clean = new StringBuffer();
		StringCharacterIterator iter = new StringCharacterIterator(s);
		char c = iter.first();
		while (c != StringCharacterIterator.DONE) {

			if (Character.isLetterOrDigit(c)) {
				clean.append(c);
			}
			else {
				clean.append("_");
			}
			c = iter.next();
		}
		return clean.toString();
	}


	/**
	 *  Removes file extension e.g. 'filename.txt' ->'filename' 
	 *
	 *@param  filename  String to trim 
	 *@return           trimmed String 
	 */
	public static String trimFileExt(String filename) {
		int dot = filename.lastIndexOf('.');
		if (dot == -1) {
			dot = filename.length();
		}
		String trim = filename.substring(0, dot);
		return trim;
	}
}

