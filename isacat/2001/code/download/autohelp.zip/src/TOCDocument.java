import java.util.*;
import org.w3c.dom.*;

/**
 *  Description of the Class 
 *
 *@author     danny 
 *@created    23 January 2001 
 */
public class TOCDocument extends HelpDocument {

	Stack stack = new Stack();


	/**
	 *  Constructor for the TOCDocument object 
	 */
	public TOCDocument() {
		createRoot("toc");
	}


	/**
	 *  Gets the StackEmpty attribute of the TOCDocument object 
	 *
	 *@return    The StackEmpty value 
	 */
	public boolean isStackEmpty() {
		return stack.size() == 0;
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	public Element peekElement() {
		return (Element) stack.peek();
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	public Element popElement() {
		return (Element) stack.pop();
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  element  Description of Parameter 
	 */
	public void pushElement(Element element) {
		stack.push(element);
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	public int stackSize() {
		return stack.size();
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  name  Description of Parameter 
	 */
	public void pushNewElement(String name) {
		pushElement(createTOCElement(name));
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  name  Description of Parameter 
	 *@return       Description of the Returned Value 
	 */
	public Element createTOCElement(String name) {
		Element newElement = createElement("tocitem");
		newElement.setAttribute("text", name);
		return newElement;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  target  Description of Parameter 
	 *@param  name    Description of Parameter 
	 *@return         Description of the Returned Value 
	 */
	public Element createTOCElement(String target, String name) {
		Element newElement = createTOCElement(name);
		newElement.setAttribute("target", target);
		return newElement;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  elepair  Description of Parameter 
	 *@return          Description of the Returned Value 
	 */
	public ElementPair stepDown(ElementPair elepair) {
		// remove parent from stack
		elepair.setParent(popElement());

		debug("popped : " + elepair.getParent().getTagName());

		elepair.parentToChild();
		// get new parent
		if (!isStackEmpty()) {
			elepair.setParent(popElement());
			debug("popped : " + elepair.getParent().getTagName());
		}
		else {
			elepair.setParent(getRoot());
			///////////////////////////////
		}

		// push parent back on stack
		pushElement(elepair.getParent());
		debug("7*pushed : " + elepair.getParent().getTagName());

		elepair.link();
		elepair.childToParent();
		return elepair;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  elepair  Description of Parameter 
	 *@return          Description of the Returned Value 
	 */
	public ElementPair stepUp(ElementPair elepair) {
		elepair.link();
		pushElement(elepair.getParent());
		elepair.childToParent();
		return elepair;
	}


	/**
	 *  Description of the Method 
	 */
	public void removeEmptyFolders() {
		NodeList nodes = getDocument().getElementsByTagName("tocitem");
		boolean noEmpty = true;
		do {
			noEmpty = false;
			for (int i = 0; i < nodes.getLength(); i++) {

				Element element = (Element) nodes.item(i);

				if (element == null) {
					continue;
				}
				if (element.hasChildNodes()) {
					continue;
				}
				if (!element.hasAttribute("target")) {
					System.out.print(".");
					debug("NO TARGET");
					noEmpty = true;
					Element parent = (Element) element.getParentNode();
					parent.removeChild(element);
				}
			}
		} while (noEmpty == true);
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  helpTitle  Description of Parameter 
	 */
	public void writeXMLFile(String helpTitle) {
		super.writeXMLFile(helpTitle + "TOC.xml");
	}
}
