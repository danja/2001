<?xml version="1.0" encoding="UTF-8"?>

<helpset version="1.0">
  <title>Test Help</title>
  <maps>
    <homeID>top</homeID>
    <mapref location="Test HelpMap.xml" />
  </maps>
  <view>
    <name>toc</name>
    <label>Table of Contents</label>
    <type>javax.help.TOCView</type>
    <data>Test HelpTOC.xml</data>
  </view>
  <view>
    <name>index</name>
    <label>Index</label>
    <type>javax.help.IndexView</type>
    <data>Test HelpIndex.xml</data>
  </view>
  <view>
    <name>Search</name>
    <label>Search</label>
    <type>javax.help.SearchView</type>
    <data engine="com.sun.java.help.search.DefaultSearchEngine">JavaHelpSearch</data>
  </view>
</helpset>

