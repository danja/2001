import org.w3c.dom.*;
import java.util.*;

/**
 *  Description of the Class 
 *
 *@author     danny 
 *@created    23 January 2001 
 */
public class IndexDocument extends HelpDocument {

	// map to contain index entries & automatically sort
	TreeMap indexArray = new TreeMap();


	/**
	 *  Constructor for the IndexDocument object 
	 */
	public IndexDocument() {
		createRoot("index");
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  mapRef  Description of Parameter 
	 *@param  name    Description of Parameter 
	 */
	public void putNewItem(String mapRef, String name) {
		Element indexItem = createElement("indexitem");
		indexItem.setAttribute("target", mapRef);
		indexItem.setAttribute("text", name);
		indexArray.put(name, indexItem);
	}


	// put the entry <indexitem target="[ref]" text="[index]"> into index

	/**
	 *  Description of the Method 
	 */
	public void buildIndex() {
		for (Iterator i = indexArray.values().iterator(); i.hasNext(); ) {
			appendToRoot((Element) i.next());
			////////////////
		}
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  helpTitle  Description of Parameter 
	 */
	public void writeXMLFile(String helpTitle) {
		super.writeXMLFile(helpTitle + "Index.xml");
	}


}
