// package com.wrox.javahelp;
/*
 * 
 * 
 */

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.xml.sax.*;

/**
 *  
 *
 *@author     Danny Ayers 
 *@created    03 January 2001 
 *@version    1.0 
 */

public class HelpHandler implements DirHandler {
	// set to true for verbose output
	MapDocument map;
	IndexDocument index;
	TOCDocument toc;
	Element tocroot = null;

	// remember the last directory visited
	Directory lastDir = new Directory();

	// starting directory
	File basedir;

	private static boolean debug = false;

	// project title
	private static String helpTitle = "Title";


	// use Directory instead ??
	/**
	 *  Constructor for the HelpHandler object 
	 */
	public HelpHandler() {
	}


	/**
	 *  Sets the Map attribute of the HelpHandler object 
	 *
	 *@param  doc  The new Map value 
	 */
	public void setMap(MapDocument doc) {
		map = doc;
	}


	/**
	 *  Sets the Index attribute of the HelpHandler object 
	 *
	 *@param  doc  The new Index value 
	 */
	public void setIndex(IndexDocument doc) {
		index = doc;
	}


	/**
	 *  Sets the TOC attribute of the HelpHandler object 
	 *
	 *@param  doc  The new TOC value 
	 */
	public void setTOC(TOCDocument doc) {
		toc = doc;
	}


	/**
	 *  Sets the BaseDir attribute of the HelpHandler object 
	 *
	 *@param  dir  The new BaseDir value 
	 */
	public void setBaseDir(File dir) {
		basedir = dir;

	}


	/**
	 *  Gets the BaseDir attribute of the HelpHandler object 
	 *
	 *@return    The BaseDir value 
	 */
	public File getBaseDir() {
		return basedir;
	}


	/**
	 *  Shows additional information at console 
	 *
	 *@param  ob  output is ob.toString() 
	 */
	public void debug(Object ob) {
		if (debug) {
			System.out.println(ob);
		}
	}


	/**
	 *  Responds to file discovery 
	 *
	 *@param  file  file as passed from tree walker 
	 */
	public void fileElement(File file) {
		ElementPair elepair = new ElementPair();

		// the directory in which this file occurs
		Directory currentDir = new Directory(new File(file.getParent()), basedir);

		// if it has changed dir here need to trap it
		if (currentDir.isMismatch(lastDir)) {
			// send as a directory change
			dirElement(file.getParentFile());
		}
		String filename = file.getName();

		// discount non-HTML
		if (!Directory.isRequiredFile(filename)) {
			return;
		}

		// creates a reference for the Map file to this file
		String mapRef = map.makeMapRef(filename, currentDir);

		map.addMapIDItem(mapRef, currentDir.getUrl(filename));

		String name = currentDir.makeNameFromFile(filename);

		// put the entry <indexitem target="[mapRef]" text="[text]"> into index array
		index.putNewItem(mapRef, name);

		elepair.setParent(toc.peekElement());

		// creates element <tocitem target="[ref]" text="[index]"> into index array
		Element fileTOCElement = toc.createTOCElement(mapRef, name);
		elepair.setChild(fileTOCElement);
		elepair.link();
	}



	/**
	 *  Responds to directory discovery 
	 *
	 *@param  file  directory found 
	 */
	public void dirElement(File file) {

		ElementPair elepair = new ElementPair();

		debug("-----------------------------------");
		if (file == basedir) {
			debug("BASEDIR");
		}

		// append base
		Directory currentDir = new Directory(file, basedir);

		debug("   lastDir = " + lastDir);
		debug("currentDir = " + currentDir);

		// initial value of child is top element in stack
		if (!toc.isStackEmpty()) {
			elepair.setChild(toc.peekElement());
			debug("peeked : " + elepair.getChild().getTagName());
		}
		else {
			System.out.println("!toc.isStackEmpty()");
		}

// walk down to common level popping and writing
		int downMismatch = currentDir.getMismatch(lastDir);
		debug("\nDOWN mismatch = " + downMismatch);

		for (int i = 0; i < downMismatch; i++) {
			// Stack's .empty() method doesn't appear to work
			if (toc.isStackEmpty()) {
				break;
			}
			elepair = toc.stepDown(elepair);
		}

		//	int upMismatch = lastDir.getMismatch(currentDir);
		//debug("\nUP mismatch = " + upMismatch);
		if (lastDir.isMismatch(currentDir)) {
			// walk up to new level pushing and writing
			for (int i = 0; i < lastDir.getMismatch(currentDir) - 1; i++) {
				elepair = toc.stepUp(elepair);
			}

			// push onto stack
			toc.pushNewElement(currentDir.makeNameFromDir());
		}
		lastDir = currentDir;
	}


	/**
	 *  Responds to empty directory discovery 
	 *
	 *@param  file  directory found 
	 */
	public void emptyDirElement(File file) {
		// nothing needed
		debug(file.getName());
	}

}

