import java.util.*;
import org.w3c.dom.*;

/**
 *  Description of the Class 
 *
 *@author     danny 
 *@created    23 January 2001 
 */
public class ElementPair {

	// stack for TOC elements
	private Stack elementStack = new Stack();
	private Element parent = null;
	private Element child = null;


	/**
	 *  Sets the Parent attribute of the ElementPair object 
	 *
	 *@param  element  The new Parent value 
	 */
	public void setParent(Element element) {
		parent = element;
	}


	/**
	 *  Sets the Child attribute of the ElementPair object 
	 *
	 *@param  element  The new Child value 
	 */
	public void setChild(Element element) {
		child = element;
	}


	/**
	 *  Gets the Parent attribute of the ElementPair object 
	 *
	 *@return    The Parent value 
	 */
	public Element getParent() {
		return parent;
	}


	/**
	 *  Gets the Child attribute of the ElementPair object 
	 *
	 *@return    The Child value 
	 */
	public Element getChild() {
		return child;
	}


	/**
	 *  Description of the Method 
	 */
	public void link() {
		parent.appendChild(child);
	}


	/**
	 *  Description of the Method 
	 */
	public void childToParent() {
		parent = child;
	}


	/**
	 *  Description of the Method 
	 */
	public void parentToChild() {
		child = parent;
	}


	/**
	 *  Description of the Method 
	 *
	 *@return    Description of the Returned Value 
	 */
	public String toString() {
		return "Parent = " + elementToString(parent)
				 + "\nChild = " + elementToString(child);
	}


	/**
	 *  Helper to display element details 
	 *
	 *@param  e  Description of Parameter 
	 *@return    Description of the Returned Value 
	 */
	public static String elementToString(Element e) {
		if (e == null) {
			return "null";
		}
		String target = e.getAttribute("target");
		if (target.equals("")) {
			target = "*";
		}

		String text = e.getAttribute("text");
		if (text.equals("")) {
			text = "*";
		}
		return "#" + e.getTagName() + " " + target + " " + text;
	}

}
