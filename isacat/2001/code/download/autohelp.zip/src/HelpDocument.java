import java.util.*;

import org.w3c.dom.*;
import javax.xml.parsers.*;

/**
 *  Description of the Class 
 *
 *@author     danny 
 *@created    23 January 2001 
 */
public class HelpDocument {

	/**
	 *  Description of the Field 
	 */
	public Document doc;

	private static boolean debug = false;
	// set to true for verbose output
	private final static String HSVERSION = "1.0";


	/**
	 *  Constructor for the HelpDocument object 
	 */
	public HelpDocument() {

		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;

		try {
			factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		doc = builder.newDocument();
	}


	/**
	 *  Gets the ElementsByTagName attribute of the HelpDocument object 
	 *
	 *@param  tagName  Description of Parameter 
	 *@return          The ElementsByTagName value 
	 */
	public NodeList getElementsByTagName(String tagName) {
		return doc.getElementsByTagName(tagName);
	}


// Additional helpers
	/**
	 *  Gets the Document attribute of the HelpDocument object 
	 *
	 *@return    The Document value 
	 */
	public Document getDocument() {
		return doc;
	}


	/**
	 *  Gets the Root attribute of the HelpDocument object 
	 *
	 *@return    The Root value 
	 */
	public Element getRoot() {
		return doc.getDocumentElement();
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  ob  Description of Parameter 
	 */
	public void debug(Object ob) {
		if (debug) {
			System.out.println(ob);
		}
	}


// Methods from Document/Node
	/**
	 *  Description of the Method 
	 *
	 *@param  child  Description of Parameter 
	 *@return        Description of the Returned Value 
	 */
	public Node appendChild(Node child) {
		doc.appendChild(child);
		return child;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  tagName  Description of Parameter 
	 *@return          Description of the Returned Value 
	 */
	public Element createElement(String tagName) {
		//	System.out.println("TAGNAME = "+tagName);
		return doc.createElement(tagName);
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  child  Description of Parameter 
	 *@return        Description of the Returned Value 
	 */
	public Node appendToRoot(Node child) {
		getRoot().appendChild(child);
		return child;
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  docType  Description of Parameter 
	 */
	public void createRoot(String docType) {
		Element root = doc.createElement(docType);
		root.setAttribute("version", HSVERSION);
		appendChild(root);
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  title  Description of Parameter 
	 */
	public void writeXMLFile(String title) {
		OutputDOM.file(getDocument(), title);
	}


	/**
	 *  Description of the Method 
	 */
	public void print() {
		OutputDOM.print(getDocument());
	}
}
