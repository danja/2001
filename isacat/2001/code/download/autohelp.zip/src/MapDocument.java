import java.util.*;
import org.w3c.dom.*;

/**
 *  Description of the Class 
 *
 *@author     danny 
 *@created    23 January 2001 
 */
public class MapDocument extends HelpDocument {

	// collection of mapping names to avoid duplicates
	HashSet existingMapRefs = new HashSet();


	/**
	 *  Constructor for the MapDocument object 
	 */
	public MapDocument() {
		createRoot("map");
	}


	/**
	 *  Creates human-friendy references for the Map file 
	 *
	 *@param  filename    filename sent 
	 *@param  currentDir  Description of Parameter 
	 *@return             friendly reference 
	 */
	public String makeMapRef(String filename, Directory currentDir) {
		// create a map reference for the url
		// starting with the cleaned-up name
		String ref = Directory.trimFileExt(filename);
		ref = Directory.tidyCase(ref);

		// get the current directory as an array
		ArrayList dirs = currentDir.getDirArray();
		int dirSize = dirs.size();
		int endDir = dirSize;
		String dir;

		// if the cleaned-up filename is 'Index'
		// use the name of the containing directory
		if ("Index".equals(filename) && (dirSize > 0)) {
			ref = (String) dirs.get(dirSize - 1);
			ref = Directory.tidyCase(ref);
			ref = Directory.clean(ref);
		}

		// if this ref has already been used, prepend the last directory name
		while (existingMapRefs.contains(ref)) {

			endDir--;
			if (endDir == -1) {
				ref = "Root" + ref;
				break;
			}
			dir = (String) dirs.get(endDir);
			dir = Directory.tidyCase(dir);
			dir = Directory.clean(dir);
			ref = dir + ref;
		}

		// add to 'already used' list
		existingMapRefs.add(ref);

		return ref;
	}


	/**
	 *  Adds a feature to the MapIDItem attribute of the MapDocument object 
	 *
	 *@param  mapRef  The feature to be added to the MapIDItem attribute 
	 *@param  url     The feature to be added to the MapIDItem attribute 
	 */
	public void addMapIDItem(String mapRef, String url) {
		Element mapID = createElement("mapID");
		mapID.setAttribute("target", mapRef);
		mapID.setAttribute("url", url);
		appendToRoot(mapID);
	}


	/**
	 *  Description of the Method 
	 *
	 *@param  helpTitle  Description of Parameter 
	 */
	public void writeXMLFile(String helpTitle) {
		super.writeXMLFile(helpTitle + "Map.xml");
	}

}
