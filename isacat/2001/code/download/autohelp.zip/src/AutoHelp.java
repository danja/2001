// package com.wrox.javahelp;
/*
 * Automatically builds XML Files
 * for JavaHelp
 * 
 * 
 */

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.xml.sax.*;

/**
 *  
 *
 *@author     Danny Ayers 
 *@created    03 January 2001 
 *@version    1.0 
 */

public class AutoHelp {

	MapDocument map;
	IndexDocument index;
	TOCDocument toc;

	Document helpSet;

	// starting directory
	File basedir;

	HelpHandler handler;

	private static boolean debug = false;
	// set to true for verbose output
	private final static String helpSetVersion = "1.0";

	// helpset title
	private static String helpTitle = "Title";


	/**
	 *  Constructor for the AutoHelp object 
	 *
	 *@param  basedirname  starting directory (as String) 
	 */
	public AutoHelp(String basedirname) {
		basedir = new File(basedirname);

		// check it can be read
		if (!basedir.canRead()) {
			System.out.println("Can't read : " + basedir);
			System.exit(1);
		}

		// a walker to go through directories
		DirWalker dw = new DirWalker();

		// the handler will respond to file & dir discovery
		handler = new HelpHandler();
		dw.setHandler(handler);

		handler.setBaseDir(basedir);

		// initialize DOM trees
		System.out.println("\nInitializing trees...");
		initTrees();

		// recurse directories
		System.out.println("\nScanning directories...");
		dw.walk(basedir);

		// add the root directory to finish tree
		handler.dirElement(basedir);

		// put Index together
		index.buildIndex();
		if (debug) {
			index.print();
		}

		// empty nodes correspond to empty directories
		System.out.print("\nRemoving Empty Directories...");
		toc.removeEmptyFolders();
		if (debug) {
			toc.print();
		}

		// create HelpSet file
		helpSet = HelpSet.makeHS(helpTitle);

		if (debug) {
			OutputDOM.print(helpSet);
		}
		// finalize DOM trees
		System.out.println("\n\nFinalizing trees...");
		finalizeTrees();
	}


	/**
	 *  Shows additional information at console 
	 *
	 *@param  ob  output is ob.toString() 
	 */
	public void debug(Object ob) {
		if (debug) {
			System.out.println(ob);
		}
	}


	/**
	 *  Tree initialization 
	 */
	private void initTrees() {

		map = new MapDocument();
		index = new IndexDocument();
		toc = new TOCDocument();

		handler.setMap(map);
		handler.setIndex(index);
		handler.setTOC(toc);
	}



	/**
	 *  Tree finalization 
	 */
	private void finalizeTrees() {
		// output map to file
		map.writeXMLFile(helpTitle);
		System.out.println("\nWriting Map file :     " + helpTitle + "Map.xml");

		// output index to file
		index.writeXMLFile(helpTitle);
		System.out.println("Writing Index file : " + helpTitle + "Index.xml");

		// output toc to file
		toc.writeXMLFile(helpTitle);
		System.out.println("Writing TOC file :     " + helpTitle + "TOC.xml");

		// output HelpSet to file
		OutputDOM.file(helpSet, helpTitle + ".hs");
		System.out.println("Writing HelpSet file :    " + helpTitle + ".hs");
	}



	/**
	 *  The main program for the AutoHelp class 
	 *
	 *@param  args  title, starting directory 
	 */
	public static void main(String[] args) {

		// default to current dir
		String basedirname = ".";

		if (args.length > 0) {
			helpTitle = args[0] + "Help";
		}
		if (args.length > 1) {
			basedirname = args[1];
		}
		System.out.println("\n\nStarting from : " + basedirname);
		new AutoHelp(basedirname);
		System.out.println("\nDONE.");
	}

}
