import java.io.*;
import org.w3c.dom.*;
/*
 * Xerces
 * import org.apache.xml.serialize.*;
 */
import org.apache.crimson.tree.*;

/**
 *  Used for serializing DOM Documents to console or file 
 *
 *@author     Danny Ayers 
 *@created    04 January 2001 
 */
public class OutputDOM {
	static XmlDocument xdoc = null;


	/**
	 *  Default print sends to console 
	 *
	 *@param  doc  Document to print 
	 */
	public static void print(Document doc) {
		print(doc, System.out);
	}


	/**
	 *  Write Document to file 
	 *
	 *@param  doc   DOM Documents 
	 *@param  name  filename 
	 */
	public static void file(Document doc, String name) {

		try {

			xdoc = (XmlDocument) doc;
			File outputFile = new File(name);
			FileOutputStream fos = new FileOutputStream(outputFile);
			xdoc.write(fos);

			/*
			 * Xerces version :
			 * File outputFile = new File(name);
			 * FileOutputStream fos = new FileOutputStream(outputFile);
			 * OutputFormat format = new OutputFormat(doc);
			 * creates a format appropriate to doc
			 * format.setIndent(3);
			 * will write to a String
			 * XMLSerializer serial = new XMLSerializer(fos, format);
			 * build serializer
			 * serial.asDOMSerializer();
			 * as a DOM Serializer
			 * serial.serialize(doc.getDocumentElement());
			 * serialize it out
			 * fos.close();
			 */
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}


	/**
	 *  Prints Document to given PrintStream 
	 *
	 *@param  doc  DOM Document 
	 *@param  ps   target PrintStream 
	 */
	public static void print(Document doc, PrintStream ps) {

		try {
			xdoc = (XmlDocument) doc;
			xdoc.write(ps);
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
	/*
	 * Xerces version :
	 * OutputFormat format = new OutputFormat(doc);
	 * creates a format appropriate to doc
	 * format.setIndent(3);
	 * StringWriter stringwrite = new StringWriter();
	 * will write to a String
	 * XMLSerializer serial = new XMLSerializer(stringwrite, format);
	 * build serializer
	 * serial.asDOMSerializer();
	 * as a DOM Serializer
	 * serial.serialize(doc.getDocumentElement());
	 * serialize it
	 * ps.println(stringwrite.toString());
	 * output it
	 */

}
