Readme for XMLToCSV

Needs jaxp.jar and crimson.jar in the classpath.

Usage :

java XMLToCSV [source] [destination] [delimiter] [number of fields]

source file = XML text file
destination file = output to write to
delimiter = character(s) that will separate data items (e.g. ",")
number of fields = number of items to put in each row of the output filee 

Samples are provided.

e.g.

java XMLToCSV source.xml output.txt , 3

