Readme for CSVToXML

Usage :

java CSVToXML [properties file] [source file] [destination file]

properties file = standard format Java Properties file
source file = comma separated values text file
destination file = output file to write to

Samples are provided.
e.g.

java CSVToXML csvprops.txt source.txt output.xml