
import ui.*;

public class Kex{
  
  public Kex() {
    new KexRun();
  }

  public static void main (String args[]) {
    new Kex();
  }
}
