package kb;

import util.*;

public class KFactBase { 
    
  KHashtable avpairs = new KHashtable();
  String value;
  int id;

  public KFactBase() {
  }

  public KFactBase(KFactBase kfb){
    value = kfb.getValue();
    avpairs = new KHashtable(kfb.getAVPairs());
    id = kfb.getId(); 
  }
 
  public void setAVPairs(KHashtable avt){
    avpairs = avt;
  }

  public KHashtable getAVPairs(){
    return avpairs;
  }
  
  public void setValue(String s){
      value = s;
    }
    
  public String getValue() {
      return value;
  }

    
  public void setId(int i){
    id = i;
  }
  
  public int getId(){
    return id;
  }

  protected void putBoolean(String s, boolean b){
    avpairs.putBoolean(s,b);
  }
  
  protected boolean getBoolean(String s){
    return avpairs.getBoolean(s);    
  }
  
  
  public void setGoal(boolean b){
    putBoolean("goal", b);
  }
  
  public boolean isGoal(){
   return getBoolean("goal");
  }
  
  public void setQuestion(boolean b){
    putBoolean("question", b);
  }
  
  public boolean isQuestion(){
    return getBoolean("question");
  }
  

    
  public String toString(){    
    return value;
  }  
}