 
package kb;

import java.util.*;

import kb.*;
import util.*;
import ui.*;


public class KDomain {

  public Vector facts = new Vector();
  public Vector rules = new Vector();
  private KHashtable lookup = new KHashtable();
  int ruleid = -1;
  int factid = -1;
  private String name = new String ("untitled");

  public KDomain() {
  }
 
  public KDomain(KDomain dom){ 
     for (Enumeration f = dom.getFacts().elements() ; f.hasMoreElements() ;) {
         facts.addElement(new KFact((KFact)f.nextElement()));
     }
     for (Enumeration r = dom.getRules().elements() ; r.hasMoreElements() ;) {
        KRule rule = (KRule)r.nextElement();
        rules.addElement(new KRule(this, rule)); 
     } 
    lookup = new KHashtable(dom.getLookup());
    name = dom.getName();
  }
      
  public int addRule(KRule rule){              
    rule.setId(++ruleid);
    rules.addElement(rule);
    KexRun.setMessage("\nAdding rule : "+(ruleid+1));
    return ruleid;
  }
  
  public int addFact(KFact fact){
    fact.setId(++factid);
    facts.addElement(fact);
    lookup.put(fact.getValue(),new Integer(factid)); 
    KexRun.setMessage("\nAdding fact : "+(factid+1)); 
    return factid;
  }

  public void setName(String s){
    KexRun.setMessage("Domain Name = "+s);
    name=s;
  }
  
  public String getName(){
    return name;
  }
  
  public Vector getRules(){
    return rules;
  }
    
  public Vector getFacts(){
     return facts;
  }
 
  public KHashtable getLookup(){
    return lookup;
  }    
    
    
      public KFact getFact(int id){ //
        return (KFact)facts.elementAt(id);
    }
    

      public int getFactId(String s) throws XException{ 
      int id;
      Object tempob = lookup.get(s);
      if(tempob == null) throw new XException("Non-existent fact : "+s);
      id = ((Integer)tempob).intValue();
        return id;
    }   
    
       public KFact getFact(String s){       
        int id = -1;
        try{
          id = getFactId(s);
        } catch(Exception e){
          System.err.println(e);
        }
      return (KFact)facts.elementAt(id);
    }
    
    public void update(KFact fact){
      int i = fact.getId();
      facts.setElementAt(fact, i);
    }

    public void update(KRule rule){
      int i = rule.getId();
      rules.setElementAt(rule, i);
    }
    
    
    public Vector getRemainingGoals(){
       KFact fact;
       Vector goals = new Vector();
      for(Enumeration g = facts.elements(); g.hasMoreElements();){ 
        fact = (KFact)g.nextElement();
        if(fact.isGoal() && !fact.isKnown()) goals.addElement(fact);
      }
      return goals;
    }
    
  public String toString(){
    String dlist = "\n\n*** Domain : "+getName()+" ***";
    dlist += "\n\n--- Facts ---\n";
    int count=0;
    if(facts != null){
      for(Enumeration ef = facts.elements(); ef.hasMoreElements();){ 
        dlist += ((KFact)ef.nextElement()).toString()+"\n";
      }
    } else dlist += "uninitialized\n";

    dlist += "\n--- Rules ---\n";
      
    if(rules != null){
      for(Enumeration er = rules.elements(); er.hasMoreElements();){ 
      dlist += ((KRule)er.nextElement()).toString()+"\n";
    }    
      } else dlist += "uninitialized\n";
    dlist += "\n*** End "+getName()+" ***";
    return dlist;
  }
}