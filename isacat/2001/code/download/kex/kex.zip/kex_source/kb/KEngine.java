/*
 * KEngine.java
 *
 */
 
package kb;

import java.util.*;
import Kex;
import util.*;

public class KEngine {

  private KDomain domain;
  private Vector factqueue = new Vector();
  private Vector asked = new Vector();

  private boolean done = false;
  private String answer = null;
  private int count = 0;

  public KEngine(KDomain dom) {
    done = false;
    domain = dom; 
  }
    
  public String getNextQuestion(){
    KFact fact;
    KFact maxq = null; 
    int qcount = 0;
    for (Enumeration e = domain.getFacts().elements(); e.hasMoreElements() ;) {  
      fact = (KFact)e.nextElement();
      if(!fact.isKnown()){
        if(fact.isQuestion()){
          if(!asked.contains(new Integer(fact.getId()))){
            qcount++;
            if(qcount == 1){
              maxq = fact;
            } else
              if(fact.getRuleRefs().size() > maxq.getRuleRefs().size()) maxq = fact; 
            }
        } // endif isQuestion
      } // endif !isKnown
    } // endfor enumeration e
    if(qcount == 0){
      done = true;
      return null;
    }
    asked.addElement(new Integer(maxq.getId()));
    return maxq.getValue();
  }
       
  public void assertFact(String value, boolean affirmed) throws XException {    
    KFact fact = domain.getFact(value);
    fact.setAffirmed(affirmed);
    assertFact(fact);
  }
    
  public void assertFact(KFact assertfact) throws XException {
    int index;  
    KRule currentrule;
  //  KFact rulefact;    
        KFact response;
        factqueue = new Vector();
    if(assertfact.getRuleRefs().size() == 0){
      KLog.println("No rules matching "+assertfact);
      return; 
    }
    KLog.println("\n\nAssertion "+(++count)+": "+assertfact.toString());
    for (Enumeration e = assertfact.getRuleRefs().elements() ; e.hasMoreElements() ;) {
      index = ((Integer)e.nextElement()).intValue();
      // individual rule
      currentrule = (KRule)domain.getRules().elementAt(index);
      KLog.println("\nChecking rule : "+currentrule.toString());
      if(!currentrule.isFired()){
        // get that rule's conditions
     //   rulefact = currentrule.getFact();
        response = currentrule.trigger(assertfact);
        if(currentrule.isFired()){  
          if(response.isGoal()){
            if(response.isAffirmed()){ 
              done = true;
              answer = response.getValue();// rulefact.getValue();
              return;                
            } 
          } 
            KLog.println("Updating : "+response.toString());
            domain.update(response);
            factqueue.addElement(response);
        } // endif response !=null
      } // end isFired

      while(!factqueue.isEmpty()){
        for (Enumeration fq = factqueue.elements() ; fq.hasMoreElements() ;){
          KFact fact = (KFact)fq.nextElement();
          assertFact(fact);
          if(done) return;
          factqueue.removeElement(fact);
        } // endfor Enumeration fq
      } // endwhile isEmpty

    } // end isFired
                  KLog.println("\nRemaining goals : "+getRemainingGoalsList());  
  } // end method
  
  public String getRemainingGoalsList(){
    if(domain.getRemainingGoals().size() == 0) return "none.";
    String gstring = new String();
    KFact fact;
    for (Enumeration g = domain.getRemainingGoals().elements() ; g.hasMoreElements() ;){  
       fact = (KFact)g.nextElement();
        gstring += "\n"+fact.getValue();  
    }
    return gstring;
  }
  
  
  public boolean isDone(){
    return done;
  }
  
  public String getAnswer(){
    return answer;
  }
  
  public String toString(){
    return domain.toString();
  }
}