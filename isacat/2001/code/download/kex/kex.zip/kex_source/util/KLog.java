/*
 * KLog.java
 */
 
package util;

public class KLog {
  public static boolean logging = false;
  
  public static void print(String s){
    if(logging) System.out.print(s);
  }

    public static void println(String s){
    if(logging) System.out.println(s);
  }
}