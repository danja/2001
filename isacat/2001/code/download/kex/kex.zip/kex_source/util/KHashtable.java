/*
 * KHashtable.java
 *
 */
 
package util;

import java.util.*;

public class KHashtable extends Hashtable {

    public KHashtable(){
      super();
    }
 
    public KHashtable(KHashtable kh){
      super();
      Object key;
     for (Enumeration e = kh.keys(); e.hasMoreElements() ;) {
        key = e.nextElement();
        put(key,kh.get(key));
      }   
    }  
    
            public void putBoolean(Object attribute, boolean b){
            if(b) put(attribute, "true"); 
                else put(attribute, "false");
        }
        
        public boolean getBoolean(Object attribute){ 
            Object value = get(attribute);
            if(value == null) return false;
            if (((String)value).equals("false")) return false;
                else return true;
        }
}