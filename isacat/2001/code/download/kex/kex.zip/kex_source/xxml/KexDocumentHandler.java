// Start of KexDocumentHandler
 
package xxml;

import ui.*;
import kb.*;
import io.*;
import util.*;

public class KexDocumentHandler implements XDocumentHandler{

  static final int  NONE = 0;
  static final int  FACT = 1;
  static final int  RULEFACT = 2;
  static final int  CONDITION = 3;
        
  private KDomain domain = new KDomain();
  private int nesting;
  private int tag = NONE;
  private KFact fact;
  private KRule rule;
  private KFact rulefact;
  private KCondition condition;
  private KHashtable avpairs = new KHashtable();
        
  public KexDocumentHandler(){
  }

  public KDomain load(String name){
    KMemoReader memo = null;       
    try{
      memo = new KMemoReader();
    } catch(Exception e){
        System.err.println(e);
      }
    KexRun.setMessage("Searching for \""+name+"\"\n");
    byte[] document = memo.getDocument(name);
    memo.close();
    if(document== null) return null;
    KexRun.setMessage("Loading "+name+"...\n");
    KParser parser = new KParser();
    parser.setSource(document);
    document = null;
    parser.setDocumentHandler(this);
    parser.parse();
    KexRun.setMessage(null);
    return domain;
  }
    
  public void startDocument(){
    KLog.println("Start Document");
  }

  public void endDocument(){
    KLog.println("\nEnd Document");
  }

  public void startElement(String name,KHashtable pairs){
    avpairs = new KHashtable(pairs);
    nesting++;
    switch(nesting){ 
      case 1: // domain
        Object nameo = avpairs.get("name");
        if(nameo != null){
        String domname = (String)nameo;
        domain.setName(domname);
      }
      break;
            
    case 2: // facts and rules        
        if(name.equals("fact")){
          tag = FACT;
          fact = new KFact();      
          fact.setAVPairs(avpairs);
        }
        if(name.equals("rule")){
          rule = new KRule(domain);
          domain.addRule(rule);
        }
        break;
                
        case 3: // within rules
          tag = NONE;
          if(name.equals("fact")){
          tag = RULEFACT;
        }
        if(name.equals("condition")){
          tag = CONDITION;
          condition = new KCondition();
          condition.setAVPairs(avpairs);
        }
        break;                 
    } // end switch
  }
  
  public void characters(String s){
    KFact cfact = null;
    
    switch(tag){
      case FACT:
        fact.setValue(s);
        break;
                
      case RULEFACT:
        try{
          rulefact = new KFact(domain.getFact(s));
          if(avpairs.getBoolean("negated")){
          rule.setNegated(true);}
          else rule.setNegated(false);
          }catch(Exception e){
              System.err.println(e);
            }
        break;
          
        case CONDITION:
          try{
            cfact = domain.getFact(s);
          } catch(Exception e){
                System.err.println(e);
              }
          cfact.addRuleRef(rule.getId());
          domain.update(cfact);
          condition.setValue(s);
          condition.setId(cfact.getId());
          rule.addCondition(condition);
          break;
          
        default :
          try{
            throw new XException("Interpretation error.");
          }catch(Exception e){
            System.err.println(e);
          }
          break;
    } // end switch    
  }  
  
  public void endElement(String name){
    nesting--;
    if(name.equals("fact") && tag != RULEFACT){
      domain.addFact(fact); 
    }
    if(name.equals("rule")){
      try{
        rule.setFact(rulefact);
      }catch(Exception e){
          System.err.println(e);
        }
      domain.update(rule);     
    }
  }
}