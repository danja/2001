/*
 * KParser.java
 */
 
package xxml;

import java.io.*;
import java.util.*;
import util.*;
import Kex;

public class KParser{

    private XDocumentHandler handler;
    private char ch;
    private byte[] source;   
    private int ch_count;
    private static final char END = (char)-1; 
    
  public KParser() {
  }

  public void setSource(byte[] s) {
    source = s;
  }
    
  public void setDocumentHandler(XDocumentHandler xdh) {
	handler = xdh;
  }  

  public char read() {
    if(ch_count<source.length){
      ch = (char)source[ch_count++];
    } else ch = END;
        return ch;
  }

    private boolean isWhite(char c) {
    return (c <= 32) || (c == 9) || (c == 13) || (c == 10) || (c > 122);
  }

  
  private void readWhite(){
      while (isWhite(ch) && (ch!=END)){ 
        read();}
  }
    
  private boolean isLetterOrDigit(char c) {
	if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 48 && c <= 57))
    return true;
	    else return false;
  }
  
  private String readString(){
    StringBuffer sb = new StringBuffer();
    while(isLetterOrDigit(ch)|| isWhite(ch)){  
      sb.append(ch);  
        read();
    }
    return new String(sb);
  }

  private String readWord(){
    StringBuffer sb = new StringBuffer();
    while(isLetterOrDigit(ch)) {   
      sb.append(ch);  
        read();
    }
    return new String(sb);
  }
    
  public void parse(){
    ch_count = 0;
    readDoc();
  }
        
  private void readDoc(){
    String name = new String();
    String attribute;
    String value;
    String chars;
    KHashtable avpairs = new KHashtable();
    handler.startDocument();
    try{
      while (ch!=END) {
        readWhite();
        if (ch == '<'){
          read();
          if(isLetterOrDigit(ch)){
            name = readWord(); 
            readWhite(); // letter or >          
            while(ch != '>' && ch != END){
              attribute = readWord();
              readWhite();  // was read
              if(ch != '=') throw new XException("parsing - unexpected character : "+ch); 
              readWhite();
              read(); // first quote 
              if(ch != '\"') throw new XException("parsing - unexpected character : "+ch);                         
              read();
              value = readString();
              read(); // second quote
              avpairs.put(attribute,value);
              readWhite();
            } // end while
            handler.startElement(name,avpairs); 
            avpairs.clear();
            read(); //  >
            if(isLetterOrDigit(ch)){
              chars = readString();
              handler.characters(chars);
            } else read();
          } else{
              if(ch == '/'){
                read();
                name = readWord();
                handler.endElement(name);
              }
          while(ch !='>' && ch != END) read(); // skip tag 
            }
      } else read();  // end if(ch == '<')  
    } // end while(ch != END)
      handler.endDocument();
  } catch(XException e){
      System.err.println(e);
      }
  } // end of method readDoc()
}