// Start of KexDocumentHandler

package com.kex.xml;

import java.util.*;

import com.kex.ui.*;
import com.kex.kb.*;
import com.kex.io.*;
import com.kex.util.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    24 April 2001
 */
public class KexDocumentHandler implements DocumentHandler {

  private KnowledgeBase knowBase = new KnowledgeBase();
  private int nesting;
  private int tag = NONE;
  private Fact fact;
  private Rule rule;
  private Fact rulefact;
  private Condition condition;
  private KHashtable avpairs = new KHashtable();

  final static int NONE = 0;
  final static int FACT = 1;
  final static int RULEFACT = 2;
  final static int CONDITION = 3;

  public KexDocumentHandler() {
  }

  public KnowledgeBase getKnowledgeBase() {
    return knowBase;
  }

  /*
   * public KnowledgeBase load(String name) {
   * KMemoReader memo = null;
   * try {
   * memo = new KMemoReader();
   * } catch (Exception e) {
   * System.err.println(e);
   * }
   * Kex.setMessage("Searching for \"" + name + "\"\n");
   * byte[] document = memo.getDocument(name);
   * memo.close();
   * if (document == null) {
   * return null;
   * }
   * Kex.setMessage("Loading " + name + "...\n");
   * ThinParser parser = new ThinParser();
   *
   *
   * String docString = new String(document); // 2750mS
   * char[] charData = new char[docString.length()];
   * docString.getChars(0, docString.length()-1, charData, 0);
   *
   * char[] charData = new char[document.length];
   * 500mS
   * for (int i = 0; i < document.length; i++) {
   * charData[i] = (char) document[i];
   * }
   * parser.setSource(charData);
   *
   * document = null;
   * parser.setDocumentHandler(this);
   * KLog.resetTimer();
   * parser.parse();
   * KLog.logTime();
   * Kex.setMessage(null);
   * return knowBase;
   * }
   */
  public void startDocument() {
    KLog.println("Start Document");
  }

  public void endDocument() {
    KLog.println("\nEnd Document");
  }

  public void startElement(String name, Hashtable pairs) {
    // KHashtable
    avpairs = new KHashtable(pairs);
    nesting++;
    switch (nesting) {
      case 1:
        // knowBase
        Object nameo = avpairs.get("name");
        if (nameo != null) {
          String domname = (String) nameo;
          knowBase.setName(domname);
        }
        break;
      case 2:
        // facts and rules
        if (name.equals("fact")) {
          tag = FACT;
          fact = new Fact();
          fact.setAVPairs(avpairs);
        }
        if (name.equals("rule")) {
          rule = new Rule(knowBase);
          knowBase.addRule(rule);
        }
        break;
      case 3:
        // within rules
        tag = NONE;
        if (name.equals("fact")) {
          tag = RULEFACT;
        }
        if (name.equals("condition")) {
          tag = CONDITION;
          condition = new Condition();
          condition.setAVPairs(avpairs);
        }
        break;
    }
    // end switch
  }

  public void characters(char[] ch, int start, int length) {
    String s = new String(ch, start, length);
    Fact cfact = null;

    switch (tag) {
      case FACT:
        fact.setValue(s);
        break;
      case RULEFACT:
        try {
          rulefact = new Fact(knowBase.getFact(s));
          if (avpairs.getBoolean("negated")) {
            rule.setNegated(true);
          } else {
            rule.setNegated(false);
          }
        } catch (Exception e) {
          System.err.println(e);
        }
        break;
      case CONDITION:
        try {
          cfact = knowBase.getFact(s);
        } catch (Exception e) {
          System.err.println(e);
        }
        cfact.addRuleRef(rule.getId());
        knowBase.update(cfact);
        condition.setValue(s);
        condition.setId(cfact.getId());
        rule.addCondition(condition);
        break;
      default:
        try {
          throw new KException("Interpretation error.");
        } catch (Exception e) {
          System.err.println(e);
        }
        break;
    }
    // end switch
  }

  public void endElement(String name) {
    nesting--;
    if (name.equals("fact") && tag != RULEFACT) {
      knowBase.addFact(fact);
    }
    if (name.equals("rule")) {
      try {
        rule.setFact(rulefact);
      } catch (Exception e) {
        System.err.println(e);
      }
      knowBase.update(rule);
    }
  }
}
