package com.kex.xml;

import java.util.Hashtable;
import com.kex.util.*;

/**
 *  Description of the Interface
 *
 * @author     Danny Ayers
 * @created    24 April 2001
 */
public interface DocumentHandler {
  public abstract void startDocument();

  public abstract void endDocument();

  public abstract void startElement(String name, Hashtable avpairs);

  // was KHashtable

  public abstract void endElement(String name);

  public abstract void characters(char[] ch, int start, int length
                                  );
}
