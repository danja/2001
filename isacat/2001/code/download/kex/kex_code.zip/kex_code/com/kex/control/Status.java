// start of Status.java
package com.kex.control;

public class Status {

  public final static int ERROR = 0;
  public final static int LOAD = 1;
  public final static int START = 2;
  public final static int QUERY = 3;
  public final static int CONCLUDE = 4;
  public final static int INIT_KB = 10;

  public final static int NO_RESPONSE = 0;
  public final static int YES = 1;
  public final static int NO = 2;
  public final static int DONTKNOW = 3;

  public static int state = 0;
  public static int previousState = 0;

  public static String message = "";
  public static String concludeText = "";
  public static String errorMessage = "ERROR";
}
