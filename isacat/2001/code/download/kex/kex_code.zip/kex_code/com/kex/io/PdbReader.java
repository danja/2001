// start of PdbReader.java
package com.kex.io;

import com.sun.kjava.*;
import com.kex.util.*;

public class PdbReader {

  private Database db;

  public PdbReader(String typeIdString, String creatorIdString, int mode) throws Exception {
    this(getId(typeIdString), getId(creatorIdString), mode);
  }

  public PdbReader(int typeId, int creatorId, int mode) throws Exception {
    db = new Database(typeId, creatorId, mode);
    if (!db.isOpen()) {
      throw new Exception("Database unavailable.");
    }
  }

  private PdbReader() {
  }

  public long getNumberOfRecords() {
    return db.getNumberOfRecords();
  }

  public byte[] readRecord(int recordNumber) {
    byte[] record = null;
    try {
      record = db.getRecord(recordNumber);
    } catch (Exception e) {
      return null;
    }
    return record;
  }

  public void close() {
    db.close();
    db = null;
  }

  public static int getId(String string) {
    if (string.length() != 4) {
      return -1;
    }
    int total = 0;
    char[] ch = new char[4];
    string.getChars(0, 4, ch, 0);
    for (int i = 0; i < 4; i++) {
      total += (int) ch[i] << ((3 - i) * 8);
    }
    return total;
  }
}// End of PdbReader.java

