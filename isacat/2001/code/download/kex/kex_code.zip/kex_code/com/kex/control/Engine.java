// start of Engine.java
package com.kex.control;

import java.util.*;
import com.kex.util.*;
import com.kex.model.*;

public class Engine {

  private KnowledgeBase knowBase;
  private Vector factQueue = new Vector();
  private Vector asked = new Vector();

  private boolean done = false;
  private String answer = null;
  private int count = 0;

  public Engine(KnowledgeBase knowBase) {
    done = false;
    this.knowBase = knowBase;
  }

  public String getNextQuestion() {
    Fact fact;
    Fact topQuestion = null;
    int questionCount = 0;
    for (Enumeration e = knowBase.getFacts().elements(); e.hasMoreElements(); ) {
      fact = (Fact) e.nextElement();
      if (!fact.isKnown()) {
        if (fact.isQuestion()) {
          if (!asked.contains(new Integer(fact.getId()))) {
            questionCount++;
            if (questionCount == 1) {
              topQuestion = fact;
            } else
              if (fact.getRuleRefs().size() > topQuestion.getRuleRefs().size()) {
              topQuestion = fact;
            }
          }
        }
        // endif isQuestion
      }
      // endif !isKnown
    }
    // endfor enumeration e
    if (questionCount == 0) {
      done = true;
      return null;
    }
    asked.addElement(new Integer(topQuestion.getId()));
    return topQuestion.getValue();
  } // end method

  public String getRemainingGoalsList() {
    if (knowBase.getRemainingGoals().size() == 0) {
      return "none.";
    }
    String gstring = new String();
    Fact fact;
    for (Enumeration g = knowBase.getRemainingGoals().elements(); g.hasMoreElements(); ) {
      fact = (Fact) g.nextElement();
      gstring += "\n" + fact.getValue();
    }
    return gstring;
  }


  public boolean isDone() {
    return done;
  }

  public String getAnswer() {
    return answer;
  }

  public void assertFact(String value, boolean affirmed) throws KException {
    Fact fact = knowBase.getFact(value);
    fact.setAffirmed(affirmed);
    assertFact(fact);
  }

  public void assertFact(Fact assertfact) throws KException {
    int index;
    Rule currentrule;
    Fact response;
    factQueue = new Vector();
    if (assertfact.getRuleRefs().size() == 0) {
      KLog.println("No rules matching " + assertfact);
      return;
    }
    KLog.println("\n\nAssertion " + (++count) + ": " + assertfact.toString());

    Rule refRule;

    for (Enumeration e = assertfact.getRuleRefs().elements(); e.hasMoreElements(); ) {
      refRule = (Rule) e.nextElement();
      currentrule = knowBase.getReferredRule(refRule);
      KLog.println("\nChecking rule : " + currentrule.toString());
      if (!currentrule.isFired()) {
        response = currentrule.trigger(assertfact);
        if (currentrule.isFired()) {
          if (response.isGoal()) {
            if (response.isAffirmed()) {
              done = true;
              answer = response.getValue();
              return;
            }
          }
          KLog.println("Updating : " + response.toString());
          knowBase.update(response);
          factQueue.addElement(response);
        }// endif response !=null
      }// end isFired

      while (!factQueue.isEmpty()) {
        for (Enumeration fq = factQueue.elements(); fq.hasMoreElements(); ) {
          Fact fact = (Fact) fq.nextElement();
          assertFact(fact);
          if (done) {
            return;
          }
          factQueue.removeElement(fact);
        } // endfor Enumeration fq
      } // endwhile isEmpty
    }// end isFired
    KLog.println("\nRemaining goals : " + getRemainingGoalsList());
  }

  public String toString() {
    return knowBase.toString();
  }
}// end of Engine.java
