// start of ErrorScreen.java
package com.kex.view;

import com.sun.kjava.*;
import com.kex.util.*;
import com.kex.control.*;

public class ErrorScreen extends Screen {

  private Graphics graphics;
  private TextBox textBoxError = new TextBox("", 10, 50, 140, 140);
  private Button buttonOK = new Button("OK", 58, 128);

  public ErrorScreen(Graphics graphics) {
    super(graphics);
  }

  public synchronized void penDown(int x, int y) {
    if (buttonOK.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      Status.state = Status.LOAD;
    }
  }

  public void paint() {

    graphics.clearScreen();
    textBoxError.setText(Status.errorMessage);
    KLog.println(Status.errorMessage);
    textBoxError.paint();
    buttonOK.paint();
    graphics.playSound(Graphics.SOUND_ERROR);
  }
} // end of ErrorScreen.java
