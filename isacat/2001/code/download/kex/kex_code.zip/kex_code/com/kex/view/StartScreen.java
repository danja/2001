// start of StartScreen.java
package com.kex.view;

import com.sun.kjava.*;
import com.kex.util.*;
import com.kex.control.*;

public class StartScreen extends Screen {

  private Graphics graphics;
  private Button buttonStart = new Button("Start", 25, 128);
  private Button buttonStartExit = new Button("Exit", 115, 128);
  private TextBox textBoxStart = new TextBox("", 25, 70, 100, 20);
  private TextBox textBoxTitle = new TextBox("KVM Expert System", 35, 25, 105, 30);

  public StartScreen(Graphics graphics) {
    super(graphics);
  }

  public synchronized void penDown(int x, int y) {
    if (buttonStartExit.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      KLog.println("\nExit Pressed.");
      System.exit(0);
    } else if (buttonStart.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      Status.message = "Initialising, please wait...";
      unregister();
      KLog.println("\n\n**** Run " + (++Kex.runcount) + " ****");
      Status.state = Status.INIT_KB;
    }
  }

  public void paint() {

    graphics.clearScreen();
    textBoxStart.setText("Knowledge Base \"" + QueryHandler.masterKB.getName() + "\"" + " loaded");
    textBoxTitle.paint();
    graphics.drawBorder(25, 15, 105, 30, Graphics.PLAIN, Graphics.RAISED);
    textBoxStart.paint();
    buttonStartExit.paint();
    buttonStart.paint();
    graphics.playSound(Graphics.SOUND_INFO);
  }
}// end of StartScreen.java
