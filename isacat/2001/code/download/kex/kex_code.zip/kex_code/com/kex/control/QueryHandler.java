// start of QueryHandler.java
package com.kex.control;

import com.kex.util.*;
import com.kex.model.*;

public class QueryHandler {

  public static KnowledgeBase masterKB = new KnowledgeBase();
  public static KnowledgeBase workingKB;
  public static Engine engine;
  public static String kbname = "none";
  public static String question;

  public QueryHandler() {
  }

  public void initKb() {
    workingKB = new KnowledgeBase(masterKB);
    engine = new Engine(workingKB);
  }

  public void query(int response) {

    boolean done = false;
    switch (response) {
      case Status.YES:
        KLog.println("Yes.");
        done = process(true);
        break;
      case Status.NO:
        KLog.println("No.");
        done = process(false);
        break;
      case Status.DONTKNOW:
        KLog.println("Don't Know.");
        done = process();
        break;
    }
    if (done) {
      Status.state = Status.CONCLUDE;
    } else {
      Status.state = Status.QUERY;
    }
    Status.message = null;
  }

  public boolean process() {
    Status.message = null;
    Status.concludeText = "\n*** Conclusions ***\n\n";
    if (engine.isDone()) {
      Status.state = Status.CONCLUDE;
      if (engine.getAnswer() != null) {
        Status.concludeText += "Solution is : " + engine.getAnswer();
      }
      KLog.println(Status.concludeText);
      KLog.println("\n***************");
      return true;
    }
    question = engine.getNextQuestion();
    if (question == null) {
      Status.concludeText += "No further questions.\n\nPossible solutions : ";
      Status.concludeText += engine.getRemainingGoalsList();
      KLog.println(Status.concludeText);
      Status.state = Status.CONCLUDE;
      return true;
    } else {
      KLog.print("\n+++ Selected question : " + question + "?\nResponse : ");
    }
    return false;
  }

  public boolean process(boolean affirmed) {
    Status.message = "Processing, please wait...";
    try {
      engine.assertFact(question, affirmed);
    } catch (Exception e) {
      System.err.println(e);
      return true;
    }
    Status.message = null;
    return process();
  }
}// end of QueryHandler.java
