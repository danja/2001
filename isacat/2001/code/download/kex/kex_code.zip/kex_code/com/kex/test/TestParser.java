/*
 * TestParser.java
 *
 * Created on 24 April 2001, 14:25
 */

package com.kex.test;

import java.io.*;
import com.kex.xml.*;

/**
 * @author     danny
 * @created    24 April 2001
 * @version
 */
public class TestParser {

  /**
   *  Creates new TestParser
   *
   * @param  filename  Description of Parameter
   */
  public TestParser(String filename) {
    ThinParser parser = new ThinParser();
    TestHandler handler = new TestHandler();
    parser.setDocumentHandler(handler);
    char[] charData = null;
    try {
      charData = loadFile(filename);
    } catch (IOException e) {
      e.printStackTrace();
      System.exit(1);
    }

    long tim = System.currentTimeMillis();
    for (int i = 0; i < 1000; i++) {
      parser.setSource(charData);
      parser.parse();
    }
    System.out.println((System.currentTimeMillis() - tim) / 10);
  }

  public char[] loadFile(String filename) throws IOException {
    File inputFile = new File(filename);
    FileInputStream in = new FileInputStream(inputFile);
    int c;
    StringBuffer data = new StringBuffer();
    while ((c = in.read()) != -1) {
      data.append((char) c);
    }

    in.close();
    System.out.println(data);
    char[] charData = new char[data.length()];
    data.getChars(0, data.length(), charData, 0);
    return charData;
  }

  /**
   * @param  args  the command line arguments
   */
  public static void main(String args[]) {
    new TestParser(args[0]);
  }
}
