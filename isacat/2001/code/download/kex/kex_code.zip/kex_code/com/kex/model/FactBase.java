// start of FactBase.java
package com.kex.model;

import com.kex.util.*;

public class FactBase {

  protected KHashtable avpairs = new KHashtable();
  protected String value;
  protected int id;

  public FactBase() {
   }

  public void setId(int i) {
    id = i;
  }

  public int getId() {
    return id;
  }

  public void setValue(String s) {
    value = s;
  }
  
  public String getValue() {
    return value;
  }
  
  public void setAVPairs(KHashtable avt) {
    avpairs = avt;
  }

  public KHashtable getAVPairs() {
    return avpairs;
  }
    
  protected boolean getBoolean(String s) {
    return avpairs.getBoolean(s);
  }

  protected void putBoolean(String s, boolean b) {
    avpairs.putBoolean(s, b);
  }
  
  public void setGoal(boolean b) {
    putBoolean("goal", b);
  }

  public void setQuestion(boolean b) {
    putBoolean("question", b);
  }

  public boolean isGoal() {
    return getBoolean("goal");
  }

  public boolean isQuestion() {
    return getBoolean("question");
  }

  public FactBase(FactBase kfb) {
    value = kfb.getValue();
    avpairs = new KHashtable(kfb.getAVPairs());
    id = kfb.getId();
  }
  
  public String toString() {
    return value;
  }  
}// end of FactBase.java
