// start of KnowledgeBase.java
package com.kex.model;

import java.util.*;
import com.kex.util.*;
import com.kex.control.*;

public class KnowledgeBase {

  public Vector facts = new Vector();
  public Vector rules = new Vector();
  int ruleid = -1;
  int factid = -1;
  private KHashtable lookup = new KHashtable();
  private String name = new String("untitled");

  public KnowledgeBase() {
  }

  public KnowledgeBase(KnowledgeBase knowBase) {
    for (Enumeration f = knowBase.getFacts().elements(); f.hasMoreElements(); ) {
      facts.addElement(new Fact((Fact) f.nextElement()));
    }
    for (Enumeration r = knowBase.getRules().elements(); r.hasMoreElements(); ) {
      Rule rule = (Rule) r.nextElement();
      rules.addElement(new Rule(this, rule));
    }
    lookup = new KHashtable(knowBase.getLookup());
    name = knowBase.getName();
  }

  public void setName(String s) {
    Status.message = "KnowledgeBase Name = " + s;
    name = s;
  }

  public String getName() {
    return name;
  }

  public Vector getRules() {
    return rules;
  }

  public Vector getFacts() {
    return facts;
  }

  public KHashtable getLookup() {
    return lookup;
  }


  public Rule getReferredRule(Rule refRule) {
    int index = refRule.getId();
    return (Rule) getRules().elementAt(index);
  }

  public Fact getFact(int id) {
    return (Fact) facts.elementAt(id);
  }


  public int getFactId(String s) throws KException {
    int id;
    Object tempob = lookup.get(s);
    if (tempob == null) {
      throw new KException("Non-existent fact : " + s);
    }
    id = ((Integer) tempob).intValue();
    return id;
  }

  public Fact getFact(String s) {
    int id = -1;
    try {
      id = getFactId(s);
    } catch (Exception e) {
      System.err.println(e);
    }
    return (Fact) facts.elementAt(id);
  }


  public Vector getRemainingGoals() {
    Fact fact;
    Vector goals = new Vector();
    for (Enumeration g = facts.elements(); g.hasMoreElements(); ) {
      fact = (Fact) g.nextElement();
      if (fact.isGoal() && !fact.isKnown()) {
        goals.addElement(fact);
      }
    }
    return goals;
  }

  public int addRule(Rule rule) {
    rule.setId(++ruleid);
    rules.addElement(rule);
    Status.message = "\nAdding rule : " + Integer.toString(ruleid + 1);
    return ruleid;
  }

  public int addFact(Fact fact) {
    fact.setId(++factid);
    facts.addElement(fact);
    lookup.put(fact.getValue(), new Integer(factid));
    Status.message = "\nAdding fact : " + Integer.toString(factid + 1);
    return factid;
  }

  public void update(Fact fact) {
    int i = fact.getId();
    facts.setElementAt(fact, i);
  }

  public void update(Rule rule) {
    int i = rule.getId();
    rules.setElementAt(rule, i);
  }

  public String toString() {
    String dlist = "\n\n*** KnowledgeBase : " + getName() + " ***";
    dlist += "\n\n--- Facts ---\n";
    int count = 0;
    if (facts != null) {
      for (Enumeration ef = facts.elements(); ef.hasMoreElements(); ) {
        dlist += ((Fact) ef.nextElement()).toString() + "\n";
      }
    } else {
      dlist += "uninitialized\n";
    }

    dlist += "\n--- Rules ---\n";

    if (rules != null) {
      for (Enumeration er = rules.elements(); er.hasMoreElements(); ) {
        dlist += ((Rule) er.nextElement()).toString() + "\n";
      }
    } else {
      dlist += "uninitialized\n";
    }
    dlist += "\n*** End " + getName() + " ***";
    return dlist;
  }
}// end of KnowledgeBase.java
