// start of DocumentHandler.java
package com.kex.xml;

import java.util.Hashtable;

public interface DocumentHandler {
  public abstract void startDocument();

  public abstract void endDocument();

  public abstract void startElement(String name, Hashtable avpairs);

  public abstract void endElement(String name);

  public abstract void characters(char[] ch, int start, int length);
}  // end of DocumentHandler.java
