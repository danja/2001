package com.kex.view;

import com.sun.kjava.*;

public abstract class Screen extends Spotlet {

  protected boolean error;
 // protected String message;
  protected Graphics graphics;

  public Screen(Graphics graphics) {
    this.graphics = graphics;
  }

  private Screen() {
  }

  public int getResponse() {
    return -1;
  }

  public abstract void paint();
}
