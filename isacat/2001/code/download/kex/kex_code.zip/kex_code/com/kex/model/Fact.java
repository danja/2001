// start of Fact.java
package com.kex.model;

import java.util.*;
import com.kex.util.*;

public class Fact extends FactBase {

  private boolean stateknown = false;
  private boolean affirmed = false;
  private Vector rulerefs = new Vector();

  public Fact() {
    super();
  }

  public Fact(Fact kf) {
    super(kf);
    rulerefs = kf.getRuleRefs();
  }

  public void setKnown(boolean b) {
    stateknown = b;
  }

  public void setAffirmed(boolean b) {
    affirmed = b;
    stateknown = true;
  }

  public void setRuleRefs(Vector v) {
    rulerefs = v;
  }

  public boolean isKnown() {
    return stateknown;
  }

  public boolean isAffirmed() throws KException {
    if (!stateknown) {
      throw new KException("Unknown fact state. ");
    }
    return affirmed;
  }

  public Vector getRuleRefs() {
    return rulerefs;
  }

  public void addRuleRef(Rule rule) {
    rulerefs.addElement(rule);
  }

  public String toString() {
    String s = super.getId() + " " + value;
    int refs;
    if (isQuestion()) {
      s += "?";
    }
    if (isGoal()) {
      s += "*";
    }
    if ((refs = rulerefs.size()) > 0) {
      s += " [" + rulerefs + "]";
    }
    if (stateknown) {
      try {
        if (affirmed) {
          s += " [TRUE]";
        } else {
          s += " [FALSE]";
        }
      } catch (Exception e) {
        System.err.println(e);
      }
    }
    return s;
  }
}// end of Fact.java
