// start of KHashtable.java

package com.kex.util;

import java.util.*;

public class KHashtable extends Hashtable {

  public KHashtable() {
    super();
  }

  public KHashtable(Hashtable h) {
    super();
    Object key;
    for (Enumeration e = h.keys(); e.hasMoreElements(); ) {
      key = e.nextElement();
      put(key, h.get(key));
    }
  }

  public KHashtable(KHashtable kh) {
    this((Hashtable) kh);
  }

  public void putBoolean(Object attribute, boolean b) {
    if (b) {
      put(attribute, "true");
    } else {
      put(attribute, "false");
    }
  }
  
  public boolean getBoolean(Object attribute) {
    Object value = get(attribute);
    if (value == null) {
      return false;
    }
    if (((String) value).equals("false")) {
      return false;
    } else {
      return true;
    }
  }


}// end of KHashtable.java
