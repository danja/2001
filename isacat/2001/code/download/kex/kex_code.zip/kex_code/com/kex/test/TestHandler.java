/*
 * TestHandler.java
 *
 * Created on 24 April 2001, 14:28
 */

package com.kex.test;

import java.util.*;
import com.kex.util.*;
/**
 * @author     danny
 * @created    24 April 2001
 * @version
 */
public class TestHandler implements com.kex.xml.DocumentHandler {

  /**
   *  Creates new TestHandler
   */
  public TestHandler() {
  }

  public void characters(char[] ch, int start, int length) {
    // System.out.println("characters : " + new String(ch, start, length));
  }

  public void endDocument() {
    //   System.out.println("end document");
  }

  public void endElement(String name) {
    // System.out.println("end element : " + name);
  }

  public void startDocument() {
    // System.out.println("start document");

  }

  public void startElement(String name, Hashtable avpairs) {
    //   System.out.println("start element : " + name + "  attrs : " + avpairs);

  }

}
