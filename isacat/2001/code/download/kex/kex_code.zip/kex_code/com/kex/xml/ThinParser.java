// start of ThinParser.java

package com.kex.xml;

import java.io.*;
import java.util.*;
import com.kex.util.*;

public class ThinParser {

  private DocumentHandler handler;
  private char currentChar;
  private char[] source;

  private int charCount;
  private int firstChar;
  private int lineCount;

  private Stack tagStack = null;

  public final static char CHAR_A = 65;
  public final static char CHAR_Z = 90;
  public final static char CHAR_a = 97;
  public final static char CHAR_z = 122;
  public final static char CHAR_0 = 48;
  public final static char CHAR_9 = 57;

  public final static char CHAR_BANG = 33;

  public final static Hashtable emptyHashtable = new Hashtable();

  public ThinParser() {

  }

  public void setSource(char[] source) {
    this.source = source;
  }

  public void setDocumentHandler(DocumentHandler handler) {
    this.handler = handler;
  }

  public void parse() {
    currentChar = 0;
    tagStack = new Stack();
    charCount = 0;
    lineCount = 1;
    readDoc();
  }

  private boolean isWhitespace(char c) {
    return (c < CHAR_BANG) || (c > CHAR_z);
  }

  private boolean isLetterOrDigit(char c) {
    return (c >= CHAR_A && c <= CHAR_Z) || (c >= CHAR_a && c <= CHAR_z) || (c >= CHAR_0 && c <= CHAR_9);
  }

  private int getLineNumber() {
    return lineCount;
  }

  private String getCharString() {
    return new String(source, firstChar - 1, charCount - firstChar);
  }

  private void readChar() throws ParseException {
    try {
      currentChar = source[charCount++];
    } catch (ArrayIndexOutOfBoundsException e) {
      throw new ParseException("unexpected end of file");
    }
    if (currentChar == '\n') {
      lineCount++;
    }
  }


  private void eatTag() throws ParseException {
    while (currentChar != '>') {
      readChar();
    }
  }

  private void testChar(char c) throws ParseException {
    if (currentChar != c) {
      throw new ParseException("read : \"" + currentChar + "\", expected : \"" + c + "\"");
    }
  }

  private void readDoc() {
    boolean inXml = false;
    handler.startDocument();
    try {
      while (charCount < source.length) {
        eatWhitespace();
        if (currentChar == '<') {
          inXml = true;
          readChar();
          if (isLetterOrDigit(currentChar)) {
            readStartElement();
            readContent();
          } else {
            if (currentChar == '/') {
              readEndElement();
            }
            eatTag();
          }
        } else {

          if (inXml) {
            testChar('>');
          }
          readChar();
        }
        // end if(currentChar == '<')
      }
      // end while(currentChar != END)
      handler.endDocument();
    } catch (ParseException e) {
      System.err.println(e);
    }
  }
  
  private void readStartElement() throws ParseException {
    String name = readWord();
    eatWhitespace();
    Hashtable avPairs;
    if (currentChar != '>') {
      avPairs = readAttributes();
    } else {
      avPairs = emptyHashtable;
    }
    tagStack.push(name);
    handler.startElement(name, avPairs);
    testChar('>');
    readChar();
    //  >
  }
  
  private Hashtable readAttributes() throws ParseException {
    Hashtable avPairs = new Hashtable();
    String attribute;
    String value;
    while (currentChar != '>') {
      attribute = readWord();
      eatWhitespace();
      testChar('=');
      eatWhitespace();
      readChar();
      testChar('\"');
      readChar();
      value = readString();
      testChar('\"');
      readChar();
      avPairs.put(attribute, value);
      eatWhitespace();
    }
    testChar('>');
    return avPairs;
  }



  private void readContent() throws ParseException {
    if (isLetterOrDigit(currentChar)) {
      readString();
      handler.characters(source, firstChar - 1, charCount - firstChar);
    } else {
      readChar();
    }
  }

  private void readEndElement() throws ParseException {
    if (tagStack.empty()) {
      throw new ParseException("tag mismatch");
    }
    readChar();
    eatWhitespace();
    String name = readWord();
    if (!name.equals((String) tagStack.pop())) {
      throw new ParseException("tag mismatch");
    }
    handler.endElement(name);
    eatWhitespace();
    testChar('>');
  }


  private void eatWhitespace() throws ParseException {
    while (isWhitespace(currentChar)) {
      readChar();
    }
  }


  private String readString() throws ParseException {
    return readString(true);
  }

  private String readWord() throws ParseException {
    return readString(false);
  }

  private String readString(boolean includeWhitespace) throws ParseException {
    firstChar = charCount;
    while (isLetterOrDigit(currentChar) || (includeWhitespace && isWhitespace(currentChar))) {
      readChar();
    }
    return getCharString();
  }

  public class ParseException extends Exception {
    public ParseException(String msg) {
      System.err.println("\nXML parse error - " + msg + " on or before line " + getLineNumber());
      System.exit(1);
    }
  }
}
