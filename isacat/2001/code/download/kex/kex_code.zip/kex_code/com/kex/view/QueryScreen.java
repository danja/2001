// start of QueryScreen.java
package com.kex.view;

import com.sun.kjava.*;

import com.kex.util.*;
import com.kex.control.*;

public class QueryScreen extends Screen {

  private Graphics graphics;
  private TextBox textBoxQuery = new TextBox("question", 20, 30, 110, 40);
  private Button buttonQuit = new Button("Quit", 108, 128);
  private Button buttonUnknown = new Button("Don't Know", 48, 80);
  private Button buttonNo = new Button("No", 108, 80);
  private Button buttonYes = new Button("Yes", 18, 80);
  private int response = Status.NO_RESPONSE;

  public QueryScreen(Graphics graphics) {
    super(graphics);
  }

  public int getResponse() {
    int temp = response;
    response = Status.NO_RESPONSE;
    return temp;
  }

  public synchronized void penDown(int x, int y) {
    boolean done = false;
    Status.message = "Working...";
    if (buttonQuit.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      Status.state = Status.START;
      return;
    } else if (buttonUnknown.pressed(x, y)) {
      response = Status.DONTKNOW;
    } else if (buttonYes.pressed(x, y)) {
      response = Status.YES;
    } else if (buttonNo.pressed(x, y)) {
      response = Status.NO;
    }
  }

  public void paint() {

    graphics.drawBorder(15, 25, 115, 45, Graphics.PLAIN, Graphics.RAISED);
    textBoxQuery.setText(QueryHandler.question + "?");
    textBoxQuery.paint();
    buttonQuit.paint();
    buttonUnknown.paint();
    buttonNo.paint();
    buttonYes.paint();
    graphics.playSound(Graphics.SOUND_INFO);
  }
}// end of QueryScreen.java
