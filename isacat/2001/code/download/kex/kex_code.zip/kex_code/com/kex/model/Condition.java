// start of Condition.java
package com.kex.model;

public class Condition extends FactBase {

  public Condition() {
  }

  public Condition(Condition condition) {
    super(condition);
    boolean negated = super.getBoolean("negated");
    super.putBoolean("negated", negated);
  }

  public void setNegated(boolean b) {
    super.putBoolean("negated", b);
  }

  public boolean isNegated() {
    return super.getBoolean("negated");
  }
}// end of Condition.java
