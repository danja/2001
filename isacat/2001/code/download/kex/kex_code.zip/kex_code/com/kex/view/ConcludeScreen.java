// start of ConcludeScreen.java
package com.kex.view;

import com.sun.kjava.*;
import com.kex.util.*;
import com.kex.control.*;

public class ConcludeScreen extends Screen {

  private TextBox textBoxConclude = new TextBox("", 25, 5, 140, 140);
  private Button buttonOK = new Button("OK", 58, 128);

  public ConcludeScreen(Graphics graphics) {
    super(graphics);
  }

  public synchronized void penDown(int x, int y) {
    if (buttonOK.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      Status.state = Status.START;
    }
  }

  public void paint() {
    graphics.clearScreen();
    textBoxConclude.setText(Status.concludeText);
    textBoxConclude.paint();
    buttonOK.paint();
    graphics.playSound(Graphics.SOUND_INFO);
  }
}// end of ConcludeScreen.java
