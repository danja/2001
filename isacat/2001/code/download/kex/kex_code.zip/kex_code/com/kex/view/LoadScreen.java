// start of LoadScreen.java
package com.kex.view;

import com.sun.kjava.*;

import com.kex.util.*;
import com.kex.xml.*;
import com.kex.io.*;
import com.kex.control.*;
import com.kex.model.*;

public class LoadScreen extends Screen {

  private Graphics graphics;
  private Button buttonLoad = new Button("Load", 25, 128);
  private Button buttonLoadExit = new Button("Exit", 115, 128);
  private TextField textFieldKb = new TextField("Knowledge Base ", 5, 78, 150, 20);
  private TextBox textBoxTitle = new TextBox("KVM Expert System", 37, 25, 100, 20);
  private CheckBox checkBoxLog = new CheckBox(20, 105, "Log");


  public LoadScreen(Graphics graphics) {
    super(graphics);
  }


  public synchronized void keyDown(int keyCode) {
    textFieldKb.handleKeyDown(keyCode);
  }

  public synchronized void penDown(int x, int y) {

    if (checkBoxLog.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      checkBoxLog.handlePenDown(x, y);
      KLog.logging = !KLog.logging;
    }
    if (buttonLoad.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      unregister();
      QueryHandler.kbname = textFieldKb.getText();
      textFieldKb.loseFocus();
      QueryHandler.masterKB = KbLoader.load(QueryHandler.kbname);
      if (QueryHandler.masterKB == null) {

        Status.state = Status.ERROR;
        Status.errorMessage = "\"" + QueryHandler.kbname + "\" not found.";
        return;
      }
      KLog.println(QueryHandler.masterKB.toString());
      KLog.print("\n" + QueryHandler.masterKB.getRules().size() + " rules, ");
      KLog.print(QueryHandler.masterKB.getFacts().size() + " facts ");
      KLog.println("including " + QueryHandler.masterKB.getRemainingGoals().size() + " goals.");
      Status.state = Status.START;
      graphics.playSound(Graphics.SOUND_ALARM);
    } else if (buttonLoadExit.pressed(x, y)) {
      graphics.playSound(Graphics.SOUND_INFO);
      KLog.println("\nExit Pressed.");
      System.exit(0);
    }
  }

  public void paint() {
    graphics.clearScreen();
    textBoxTitle.paint();
    graphics.drawBorder(25, 15, 105, 30, Graphics.PLAIN, Graphics.RAISED);
    buttonLoad.paint();
    buttonLoadExit.paint();
    textFieldKb.setText("");
    textFieldKb.paint();
    checkBoxLog.paint();
    textFieldKb.setFocus();
    MessageScreen.message = null;
    graphics.playSound(Graphics.SOUND_INFO);
  }
}// end of LoadScreen.java
