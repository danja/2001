// start of Rule.java

package com.kex.model;

import java.util.*;
import com.kex.util.*;

public class Rule {

  private KnowledgeBase knowBase;
  private int id = -1;
  private int factid = -1;
  private KHashtable conditions = new KHashtable();
  private boolean negated = false;
  private boolean fired = false;

  private String outstring = new String();
  private boolean dirty = true;

  public Rule(KnowledgeBase knowBase) {
    this.knowBase = knowBase;
  }

  public Rule(KnowledgeBase knowBase, Rule rule) {
    this(knowBase);
    factid = rule.getFactId();
    conditions = new KHashtable(rule.getConditionsTable());
    id = rule.getId();
    negated = rule.isNegated();
  }

  public void setFact(Fact fact) {
    dirty = true;
    factid = fact.getId();
  }

  public void setId(int i) {
    dirty = true;
    id = i;
  }

  public void setNegated(boolean b) {
    dirty = true;
    negated = b;
  }

  public void setFired(boolean b) {
    dirty = true;
    fired = b;
  }

  public KnowledgeBase getKb() {
    return knowBase;
  }

  public KHashtable getConditionsTable() {
    return conditions;
  }

  public Fact getFact() {
    return knowBase.getFact(factid);
  }

  public int getFactId() {
    return factid;
  }

  public int getId() {
    return id;
  }

  public boolean isFired() {
    return fired;
  }


  public void addCondition(Condition condition) {
    dirty = true;
    conditions.putBoolean(new Integer(condition.getId()), condition.isNegated());
  }


  public Fact trigger(Fact triggerfact) {
    boolean match;
    Condition condition;
    int conid;
    boolean connegated;
    int triggerid = triggerfact.getId();
    boolean conditionstate = false;
    boolean resultstate = false;

    for (Enumeration ec = conditions.keys(); ec.hasMoreElements(); ) {
      Object key = ec.nextElement();
      conid = ((Integer) key).intValue();
      connegated = conditions.getBoolean(key);
      match = (conid == triggerid);
      if (match) {
        try {
          conditionstate = triggerfact.isAffirmed() ^ connegated;
        } catch (Exception e) {
          System.err.println(e);
        }
        if (conditionstate) {
          conditions.remove(key);
          dirty = true;
          knowBase.update(this);
          KLog.println("Updating : " + this);
          if (conditions.size() == 0) {
            fired = true;
          }
        } else {
          fired = true;
        }

        if (fired) {
          resultstate = isNegated() ^ conditionstate;
          Fact rulefact = getFact();
          rulefact.setAffirmed(resultstate);
          return rulefact;
        }
      } // endif match
    } // endfor enum
    return null;
  } // end method

  public String toString() {
    int conid;
    boolean connegated;
    Object key;
    if (factid == -1) {
      return "uninitialized";
    }
    if (!dirty) {
      return outstring;
    }
    outstring = String.valueOf(getId());
    outstring += " IF ";
    Enumeration ec = conditions.keys();
    if (ec.hasMoreElements()) {
      key = ec.nextElement();
      conid = ((Integer) key).intValue();
      connegated = conditions.getBoolean(key);
      if (connegated) {
        outstring += "NOT ";
      }
      outstring += knowBase.getFact(conid).getValue();
    }
    while (ec.hasMoreElements()) {
      outstring += " AND ";
      key = ec.nextElement();
      conid = ((Integer) key).intValue();
      connegated = conditions.getBoolean(key);
      if (connegated) {
        outstring += "NOT ";
      }
      outstring += knowBase.getFact(conid).getValue();
    }
    outstring += " THEN ";
    if (isNegated()) {
      outstring += "NOT ";
    }
    outstring += knowBase.getFact(factid).getValue();
    dirty = false;
    return outstring;
  }

  private boolean isNegated() {
    return negated;
  }
}// end of Rule.java
