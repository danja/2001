// start of Kex.java
package com.kex.control;

import com.sun.kjava.*;
import com.kex.control.*;
import com.kex.util.*;
import com.kex.xml.*;
import com.kex.view.*;

public class Kex {

  private Graphics graphics;
  private MessageScreen messageScreen;
  private Button buttonOK = new Button("OK", 58, 128);
  private QueryHandler queryHandler;
  public static int runcount = 0;
  private static Screen[] screens;

  public Kex() {
    initScreens();
    queryHandler = new QueryHandler();
    Status.state = 1;
    while (true) {
      Status.message = null;
      graphics.clearScreen();
      Status.previousState = Status.state;
      if (Status.state == Status.INIT_KB) {
        queryHandler.initKb();
        queryHandler.process();
        Status.state = Status.QUERY;
      }

      if (Status.state == Status.QUERY) {

        screens[Status.state].paint();
        screens[Status.state].register(Spotlet.NO_EVENT_OPTIONS);
        screens[Status.state].paint();
        int response;
        while ((response = screens[Status.state].getResponse()) == Status.NO_RESPONSE) {
          try {
            Thread.sleep(10);
          } catch (Exception e) {
            System.err.println(e);
          }
        }
        messageScreen.paint();
        queryHandler.query(response);
      }
      Graphics.getGraphics().playSound(Graphics.SOUND_INFO);
      screens[Status.state].register(Spotlet.NO_EVENT_OPTIONS);
      screens[Status.state].paint();

      while (Status.state == Status.previousState) {
        messageScreen.paint();
      }
    } // endwhile true
  }

  private void initScreens() {
    graphics = Graphics.getGraphics();
    screens = new Screen[5];
    screens[Status.LOAD] = new LoadScreen(graphics);
    screens[Status.START] = new StartScreen(graphics);
    screens[Status.QUERY] = new QueryScreen(graphics);
    screens[Status.CONCLUDE] = new ConcludeScreen(graphics);
    screens[Status.ERROR] = new ErrorScreen(graphics);
    messageScreen = new MessageScreen(graphics);
  }

  public static void main(String args[]) {
    new Kex();
  }
}// end of Kex.java
