// Start of KMemoReader.java
package com.kex.io;

import com.sun.kjava.*;
import com.kex.util.*;
import com.kex.control.*;

public class KMemoReader extends PdbReader {

  public KMemoReader() throws Exception {
    super("DATA", "memo", Database.READONLY);
  }

  public byte[] getDocument(String name) {
    name = "\"" + name + "\"";
    int namelength = name.length();
    byte[] record;

    String head = new String();
    for (int recordNumber = 0; recordNumber < getNumberOfRecords(); recordNumber++) {
      KLog.println("Reading record " + recordNumber);

      record = super.readRecord(recordNumber);

      if (record.length > 20) {
        head = new String(record, 0, 20);
        if (head.regionMatches(true, 0, "Kex", 0, 3)) {
          KLog.println("\nFound a Kex KB :\n" + head + "...\n");
          if (head.regionMatches(true, 4, name, 0, namelength)) {

            return record;
          }
        }// endif "Kex"
      }// endif length()>100
      Status.message += "*";
    } // endfor record
    return null;
  }
}// End of KMemoReader.java

