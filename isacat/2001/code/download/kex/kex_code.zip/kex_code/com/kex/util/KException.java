// start of KException.java
package com.kex.util;

public class KException extends Exception {

  public KException() {
  }

  public KException(String msg) {

    super(msg);
    System.err.println("\n" + msg);

    System.exit(1);
  }
}// end of KException.java

