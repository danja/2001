// start of MessageScreen.java
package com.kex.view;

import com.sun.kjava.*;
import com.kex.util.*;
import com.kex.control.*;

public class MessageScreen extends Screen {
  public static Graphics graphics;
  public static String message;
  private static TextBox textBoxMessage = new TextBox("message", 25, 58, 110, 60);

  public MessageScreen(Graphics graphics) {
    super(graphics);
  }

  public void paint() {

    if (Status.message != null) {
      graphics.clearScreen();
      graphics.drawBorder(15, 50, 130, 40, Graphics.GRAY, Graphics.SIMPLE);
      textBoxMessage.setText(Status.message);
      textBoxMessage.paint();
      try {
        Thread.sleep(500);
      } catch (Exception e) {
        System.err.println(e);
      }
    }  // endif message != null

    try {
      Thread.sleep(100);
    } catch (Exception e) {
      System.err.println(e);
    }
  }
}// end of MessageScreen.java
