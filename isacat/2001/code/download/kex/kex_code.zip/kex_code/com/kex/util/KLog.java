// start of KLog.java

package com.kex.util;

public class KLog {
  public static boolean logging = false;
  private static long startTime = System.currentTimeMillis();

  public static void print(String s) {
    if (logging) {
      System.out.print(s);
    }
  }

  public static void println(String s) {
    if (logging) {
      System.out.println(s);
    }
  }

  public static void resetTimer() {
    startTime = System.currentTimeMillis();
  }

  public static void logTime(String message) {
    System.out.println(message + (System.currentTimeMillis() - startTime));
  }

  public static void logTime() {
    logTime("timer : ");
  }

}// end of KLog.java
