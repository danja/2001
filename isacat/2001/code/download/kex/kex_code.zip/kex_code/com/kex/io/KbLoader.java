// start of KbLoader.java
package com.kex.io;

import com.kex.model.*;
import com.kex.control.*;
import com.kex.xml.*;
import com.kex.util.*;

public class KbLoader {

  public static KnowledgeBase load(String name) {
    KMemoReader memo = null;
    try {
      memo = new KMemoReader();
    } catch (Exception e) {
      System.err.println(e);
    }
    Status.message = "Searching for \"" + name + "\"\n";
    byte[] document = memo.getDocument(name);
    memo.close();
    if (document == null) {
      return null;
    }
    Status.message = "Loading " + name + "...\n";

    char[] charData = new char[document.length];
    for (int i = 0; i < document.length; i++) {
      charData[i] = (char) document[i];
    }
    ThinParser parser = new ThinParser();
    parser.setSource(charData);

    document = null;
    DocumentHandler handler = new KexDocumentHandler();
    parser.setDocumentHandler(handler);
    KLog.resetTimer();
    parser.parse();
    KLog.logTime();
    Status.message = null;
    return ((KexDocumentHandler) handler).getKnowledgeBase();
  }
}// end of KbLoader.java
