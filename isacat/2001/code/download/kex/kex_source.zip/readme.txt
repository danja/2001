This zip file contains all the files use to create the KVM Expert System for the Palm, on Windows using the J2ME Palm Release.

The .\release directory contains the application as it might be distributed, the .\build directory and its subdirectories contain the source files together with compiled, preverified and packaged binaries. 

Batch files in the \build directory may be used to rebuild the application, though the environment variables in these will need changing to match your Java installation. 

The API documentation can be found in the .\release\docs directory, and there is another readme which describes the application's use in the .\release directory.