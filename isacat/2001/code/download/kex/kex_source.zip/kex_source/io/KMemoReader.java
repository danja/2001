// Start of KMemoReader.java
package io;

import com.sun.kjava.*;
import util.*;
import ui.*;

public class KMemoReader{

    private Database db;

    public KMemoReader() throws XException {
        db = new Database(1145132097,  1835363695, Database.READONLY);
        if(!db.isOpen()) throw new XException("Memo unavailable.");
    }        

    public void close(){
        db.close();
        db = null;
    }

    public long getNumberOfRecords(){
        return db.getNumberOfRecords();
    }



    public byte[] getDocument(String name){

        name = "\""+name+"\"";
        int namelength = name.length();
        byte[]  record;

        String head = new String();
        for(int recordNumber = 0; recordNumber < getNumberOfRecords(); recordNumber++){
            KLog.println("Reading record "+recordNumber);
            try{
                 
        record = db.getRecord(recordNumber);

                } catch(Exception e){                      
                    return null;
                  }
                  if(record.length>20){ 
                    head = new String(record,0,20);
                if(head.regionMatches(true, 0,"Kex",0,3)){
                    KLog.println("\nFound a Kex KB :\n"+head+"...\n");
                    if(head.regionMatches(true, 4, name, 0, namelength)){

                        return record;
                    } 
                } // endif "Kex" 
            } // endif length()>100
            KexRun.setMessage(KexRun.getMessage()+("*")); 
        } // endfor record
        return null;
    }
} // End of KMemoReader.java

