package ui;

import com.sun.kjava.*;
import kb.*;
import util.*;
import xxml.*;


public class KexRun extends Spotlet  {


  private static final int ERROR = -1;
  private static final int LOAD = 0;
  private static final int START = 1;       
  private static final int QUERY = 2;
  private static final int CONCLUDE = 3;

  private static int current = LOAD;
  private static int old;
  
  private static String message;
  private static String errorText;

  private LoadHandler loadHandler = new LoadHandler();
  private StartHandler startHandler = new StartHandler();
  private QueryHandler queryHandler = new QueryHandler();
  private ConcludeHandler concludeHandler = new ConcludeHandler();
  private ErrorHandler errorHandler = new ErrorHandler();

  private KDomain master = new KDomain(); 
  private KDomain domain= new KDomain();  
  private KEngine engine;  
  
  private String kbname = "none";
  private String question;
  private String concludeText;

  private  Graphics g = Graphics.getGraphics();
// load
  private  Button buttonLoad = new Button( "Load", 25, 128);
  private  Button buttonLoadExit = new Button( "Exit", 115, 128);
  private  TextField textFieldKB = new TextField( "Knowledge Base ", 5, 78, 150, 20);
  private  TextBox textBoxTitle = new TextBox( "KVM Expert System", 37, 25, 100, 20);
  private  CheckBox checkBoxLog = new CheckBox(20, 105, "Log");
// start       
  private  Button buttonStart = new Button( "Start", 25, 128);
  private  Button buttonStartExit = new Button( "Exit", 115, 128);
  private  TextBox textBoxStart = new TextBox( "", 25, 70, 100, 20);
  // query
  private  TextBox textBoxQuery = new TextBox( "question", 20, 30, 110, 40);
  private  Button buttonQuit = new Button( "Quit", 108, 128);
  private  Button buttonUnknown = new Button( "Don't Know", 48, 80);
  private  Button buttonNo = new Button( "No", 108, 80);
  private  Button buttonYes = new Button( "Yes", 18, 80);
// conclude
  private  TextBox textBoxConclude = new TextBox( "", 25, 5, 140, 140);
//  Button buttonOK = new Button( "OK", 65, 128);
  private    Button buttonOK = new Button( "OK", 58, 128);
// error
  private  TextBox textBoxError = new TextBox( "", 10, 50, 140, 140);    
// message
  private  TextBox textBoxMessage = new TextBox( "message", 25, 58, 110, 60);

  private int runcount = 0;

  public KexRun(){
    while(true){
      setMessage(null);
      g.clearScreen();
      old = current;
      
      switch (current){

        case LOAD :
          loadHandler.register(NO_EVENT_OPTIONS);
          break;
          
        case START :
          startHandler.register(NO_EVENT_OPTIONS);
          break;
          
        case QUERY :
          textBoxQuery.setText(question);
          queryHandler.register(NO_EVENT_OPTIONS);
          break;
            
        case CONCLUDE :
          textBoxConclude.setText(concludeText);
          concludeHandler.register(NO_EVENT_OPTIONS);
          break;

        case ERROR :
          textBoxError.setText(errorText);
          errorHandler.register(NO_EVENT_OPTIONS);
          break;
      } // end switch

      paint();
      while(current == old){
        
      if(getMessage() != null){
        g.clearScreen();  
        g.drawBorder( 15, 50, 130, 40, Graphics.GRAY, Graphics.SIMPLE);
        textBoxMessage.setText(getMessage());
        textBoxMessage.paint();             
        try{
          Thread.sleep(500);
          } catch(Exception e){
              System.err.println(e);
            }
      } // endif message != null
                
      try{
        Thread.sleep(100); 
      }catch(Exception e){
          System.err.println(e);
        }
      } // endwhile current == old
                g.playSound(Graphics.SOUND_INFO);     
    } // endwhile true
  } // end constructor


  public void paint() {
    g.clearScreen();
    switch (current){
      case LOAD :
        textBoxTitle.paint(); 
        g.drawBorder( 25, 15, 105, 30, Graphics.PLAIN, Graphics.RAISED);         
        buttonLoad.paint();
        buttonLoadExit.paint();
        textFieldKB.paint();
        checkBoxLog.paint();
        textFieldKB.setFocus();    
        setMessage(null);
        g.playSound(Graphics.SOUND_INFO);
        break;
          
        case START :
          textBoxTitle.paint(); 
          g.drawBorder( 25, 15, 105, 30, Graphics.PLAIN, Graphics.RAISED);
          textBoxStart.paint();
          buttonStartExit.paint();
          buttonStart.paint();
           g.playSound(Graphics.SOUND_INFO);
          break;
          
        case QUERY :
          g.drawBorder(15, 25, 115, 45, Graphics.PLAIN, Graphics.RAISED);
          textBoxQuery.setText(question+"?");
          textBoxQuery.paint();
          buttonQuit.paint();
          buttonUnknown.paint();
          buttonNo.paint();
          buttonYes.paint();
          g.playSound(Graphics.SOUND_INFO);
          break;
            
        case CONCLUDE :
          textBoxConclude.paint();
          buttonOK.paint();
          g.playSound(Graphics.SOUND_INFO);
          break;
          
        case ERROR :
          KLog.println(errorText);
          textBoxError.paint();
          buttonOK.paint();
          g.playSound(Graphics.SOUND_ERROR);
          break;
     } // end switch
  }
  
  public static void setMessage(String s){
    message = s;
    if(message != null) KLog.print(s);
  }
  
  public static String getMessage(){
    return message;
  }
 
  public class LoadHandler extends Spotlet{

    public synchronized void keyDown(int keyCode) {
      textFieldKB.handleKeyDown(keyCode);
    } 
    
    public synchronized void penDown(int x, int y) {  
      
      if(checkBoxLog.pressed(x,y)){
        g.playSound(Graphics.SOUND_INFO); 
        checkBoxLog.handlePenDown(x,y);
        KLog.logging = !KLog.logging;
      }
          
      if (buttonLoad.pressed(x, y)) {
        g.playSound(Graphics.SOUND_INFO);     
        unregister();
        kbname = textFieldKB.getText();
        textFieldKB.loseFocus(); 
        KexDocumentHandler  handler = new KexDocumentHandler();
        master = handler.load(kbname);
        handler = null;
        if(current == ERROR) return;
        if(master == null) {
          error("\""+kbname+"\" not found.");
          return;
        }
        textBoxStart.setText("Knowledge Base \""+master.getName()+"\""+" loaded");  
        KLog.println(master.toString());
        KLog.print("\n"+master.getRules().size()+" rules, ");
        KLog.print(master.getFacts().size()+" facts ");
        KLog.println("including "+master.getRemainingGoals().size()+" goals."); 
        current = START;
        g.playSound(Graphics.SOUND_ALARM);
      } else if (buttonLoadExit.pressed(x, y)) {
                  g.playSound(Graphics.SOUND_INFO);   
                          KLog.println("\nExit Pressed.");
          System.exit(0);
          }
    }
  }
	
  public class StartHandler extends Spotlet{
      
    public synchronized void penDown(int x, int y) { 

      if (buttonStartExit.pressed(x, y)) {
        g.playSound(Graphics.SOUND_INFO);     
        KLog.println("\nExit Pressed.");
        System.exit(0);
        } else if (buttonStart.pressed(x, y)) {
            g.playSound(Graphics.SOUND_INFO);     
            setMessage("Initialising, please wait...");
            unregister();
            KLog.println("\n\n**** Run "+(++runcount)+" ****");
            concludeText = "\n*** Conclusions ***\n\n";
            domain = new KDomain(master);
            engine = new KEngine(domain);
            process(); 
            current = QUERY;
            queryHandler.register(NO_EVENT_OPTIONS);
      }
    }
  }

  public class QueryHandler extends Spotlet{
    
    public synchronized void penDown(int x, int y) {
      boolean done = false;
      if (buttonQuit.pressed(x, y)) {
        g.playSound(Graphics.SOUND_INFO);     
        current = START;
      return;
      } else if (buttonUnknown.pressed(x, y)) {
                g.playSound(Graphics.SOUND_INFO);     
                KLog.println("Don't Know.");
                done = process();
              } else if (buttonYes.pressed(x, y)) {
                          g.playSound(Graphics.SOUND_INFO);     
                        KLog.println("Yes.");
                        done = process(true);
                      } else if (buttonNo.pressed(x, y)) {
                                  g.playSound(Graphics.SOUND_INFO);     
                                KLog.println("No.");
                                done = process(false);
                              }
       paint();
       if(!done) this.register(NO_EVENT_OPTIONS);
    }
  }
	
  public class ConcludeHandler extends Spotlet{
    
    public synchronized void penDown(int x, int y) {
      if (buttonOK.pressed(x, y)) {
          g.playSound(Graphics.SOUND_INFO); 
        current = START;
        paint();
        }
      }
    }
    
   public class ErrorHandler extends Spotlet{
     
      public synchronized void penDown(int x, int y) {
        if (buttonOK.pressed(x, y)) {
            g.playSound(Graphics.SOUND_INFO); 
          current = LOAD;
          paint();
        }
      }
    }    

    public static void error(String msg){
      errorText = "Error :\n"+msg;
      KLog.println(errorText);
      message = null;
      current = ERROR;
    }
    
    private boolean process(){
    //  unregister(); 
      setMessage(null);
      if(engine.isDone()){
        current = CONCLUDE;
        if(engine.getAnswer() != null)
              concludeText += "Solution is : "+engine.getAnswer();
        KLog.println(concludeText);
        KLog.println("\n***************");
        return true;
      }
      question = engine.getNextQuestion();
      if(question == null) {
        concludeText += "No further questions.\n\nPossible solutions : ";
        concludeText += engine.getRemainingGoalsList();
        KLog.println(concludeText);
        current = CONCLUDE;
        return true;
      } else KLog.print("\n+++ Selected question : "+question+"?\nResponse : ");
      return false;
   }     
   
    private boolean process(boolean affirmed){
      setMessage("Processing, please wait...");
      try{
        engine.assertFact(question, affirmed);
      } catch(Exception e){
            System.err.println(e);
            return true;
          }
      setMessage(null);
      return process();
    }
      
      
}