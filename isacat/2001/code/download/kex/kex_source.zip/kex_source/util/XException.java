package util;

import ui.*;

public class XException extends Exception {

  public XException() {
  }

  public XException(String msg) {
    
//    super(msg);
//    System.err.println("\n"+msg);
 //   System.exit(1);
    KexRun.error(msg);
  }
}

