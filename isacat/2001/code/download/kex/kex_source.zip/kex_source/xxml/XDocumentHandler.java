package xxml;

import util.*;

public interface XDocumentHandler{
    public abstract void startDocument();
    public abstract void endDocument();
    public abstract void startElement(String name, KHashtable avpairs);
    public abstract void endElement(String name);
    public abstract void characters(String s);
}