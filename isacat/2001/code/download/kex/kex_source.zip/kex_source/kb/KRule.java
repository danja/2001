/*
 * KRule.java
 *
 * Created on 09 September 2000, 15:13
 */
 
package kb;

import java.util.*;
import util.*;

public class KRule { 

  private KDomain domain;
  private int id = -1;
  private int factid = -1;
  private KHashtable conditions = new KHashtable();
  private boolean negated = false;
  private boolean fired = false;

  private String outstring = new String();
  private boolean dirty = true;
  
  public KRule(KDomain dom){
    domain = dom;
  }
  
  public KRule(KDomain dom, KRule rule){
    this(dom);
    factid = rule.getFactId();
    conditions = new KHashtable(rule.getConditionsTable());
    id = rule.getId();
    negated = rule.isNegated();
  }

  public KHashtable getConditionsTable(){
    return conditions;
  }

    public void setFact(KFact fact){ 
    dirty = true;
    factid = fact.getId();
  }
  
  public KFact getFact(){
    return domain.getFact(factid);
  }
  
  public int getFactId(){
    return factid;
  }
  
  
  public void addCondition(KCondition condition){
    dirty = true;
    conditions.putBoolean(new Integer(condition.getId()), condition.isNegated());
  }
  
  public void setId(int i){
    dirty = true;
    id = i;
  }
  
  public int getId(){
    return id;
  }

  public void setNegated(boolean b){
    dirty = true;
    negated = b;
  }
  
  private boolean isNegated(){
    return negated;
  }

  public void setFired(boolean b){
    dirty = true;
    fired = b;
  }
  
  public boolean isFired(){
    return fired;
  }
  

  

  


  public KFact trigger(KFact triggerfact){
    boolean match;
    KCondition condition;
    int conid;
    boolean connegated;
    int triggerid = triggerfact.getId();
    boolean conditionstate = false;
    boolean resultstate = false;

    
    for (Enumeration ec = conditions.keys() ; ec.hasMoreElements() ;){
      Object key = ec.nextElement();
      conid = ((Integer)key).intValue();
      connegated = conditions.getBoolean(key);
      match = (conid == triggerid);
      if(match){  
        try{
   //       conditionstate = !(triggerfact.isAffirmed() ^ !connegated);
          conditionstate = triggerfact.isAffirmed() ^ connegated;
        } catch(Exception e){
          System.err.println(e);
          }
        if(conditionstate) {      
          conditions.remove(key);
          dirty = true;
          domain.update(this);
          KLog.println("Updating : "+this);
          if(conditions.size() == 0) fired = true;
          } else {   
               fired = true;
              }
            
        if(fired){         
          resultstate = isNegated() ^ conditionstate;  
          KFact rulefact = getFact();
          rulefact.setAffirmed(resultstate);
          return rulefact;
        }
      } // endif match
    } // endfor enum
    return null;
  } // end method
        


  public String toString(){
    int conid;
    boolean connegated;
    Object key;
    if(factid == -1) return "uninitialized";
    if(!dirty) return outstring;
    outstring = String.valueOf(getId());
    outstring += " IF ";
    Enumeration ec = conditions.keys();
    if(ec.hasMoreElements()){
      key    = ec.nextElement();
      conid = ((Integer)key).intValue();
      connegated = conditions.getBoolean(key);
      if(connegated) outstring += "NOT ";
      outstring += domain.getFact(conid).getValue();
    }
    while(ec.hasMoreElements()) {
        outstring += " AND ";
              key    = ec.nextElement();
      conid = ((Integer)key).intValue();
      connegated = conditions.getBoolean(key);
        if(connegated) outstring += "NOT ";
        outstring += domain.getFact(conid).getValue();
     }
    outstring += " THEN ";
    if(isNegated()) outstring += "NOT ";
    outstring += domain.getFact(factid).getValue();
    dirty = false;
    return outstring;
  }
}