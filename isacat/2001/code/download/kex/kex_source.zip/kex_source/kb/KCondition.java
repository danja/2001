
 
package kb;

public class KCondition extends KFactBase{

  public KCondition() {
  }

  public KCondition(KCondition kcon){
    super(kcon);
    boolean negated = super.getBoolean("negated");
    super.putBoolean("negated", negated);
  }
    
    public void setNegated(boolean b){
    super.putBoolean("negated", b);
  }
  
  public boolean isNegated(){
    return super.getBoolean("negated");
  }
}