AutoHelp v 1.1

You need to install a Java Runtime Environment & JavaHelp if you haven't already.
JDK 1.3 requires JavaHelp 1.1.1 or later.

Once the above are installed, modify the batch files to match your setup, and try running them.

danny@panlanka.net

All material (c) Danny Ayers 2001. All rights reserved. 



