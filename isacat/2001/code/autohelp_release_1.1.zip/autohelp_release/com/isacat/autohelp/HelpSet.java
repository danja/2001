package com.isacat.autohelp;

import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.apache.crimson.tree.*;
/*
 * Xerces
 * import org.apache.xerces.dom.*;
 */

/**
 *  Creates a DOM Document corresponding to a JavaHelp help set. Only variable
 *  is name. Crude but effective!
 *
 * @author     Danny Ayers
 * @created    02 April 2001
 */

public class HelpSet {

  /**
   *  Creates the named .hs file
   *
   * @param  filename  name of HelpSet
   * @return           DOM document containing HelpSet
   */
  public static Document makeHS(String filename) {

    Document doc = (new HelpDocument()).getDocument();
    /*
     * Xerces version :
     * Document doc = new DocumentImpl();
     */
    Element root = doc.createElement("helpset");
    root.setAttribute("version", "1.0");

    Element title = doc.createElement("title");
    Text text = doc.createTextNode(filename);
    title.appendChild(text);
    root.appendChild(title);

    Element maps = doc.createElement("maps");

    Element homeID = doc.createElement("homeID");
    text = doc.createTextNode("top");
    homeID.appendChild(text);
    maps.appendChild(homeID);

    Element mapref = doc.createElement("mapref");
    mapref.setAttribute("location", filename + "Map.xml");
    maps.appendChild(mapref);

    root.appendChild(maps);

    Element tocview = doc.createElement("view");

    Element tocname = doc.createElement("name");
    text = doc.createTextNode("toc");
    tocname.appendChild(text);
    tocview.appendChild(tocname);

    Element toclabel = doc.createElement("label");
    text = doc.createTextNode("Table of Contents");
    toclabel.appendChild(text);
    tocview.appendChild(toclabel);

    Element toctype = doc.createElement("type");
    text = doc.createTextNode("javax.help.TOCView");
    toctype.appendChild(text);
    tocview.appendChild(toctype);

    Element tocdata = doc.createElement("data");
    text = doc.createTextNode(filename + "TOC.xml");
    tocdata.appendChild(text);
    tocview.appendChild(tocdata);

    root.appendChild(tocview);

    Element indexview = doc.createElement("view");

    Element indexname = doc.createElement("name");
    text = doc.createTextNode("index");
    indexname.appendChild(text);
    indexview.appendChild(indexname);

    Element indexlabel = doc.createElement("label");
    text = doc.createTextNode("Index");
    indexlabel.appendChild(text);
    indexview.appendChild(indexlabel);

    Element indextype = doc.createElement("type");
    text = doc.createTextNode("javax.help.IndexView");
    indextype.appendChild(text);
    indexview.appendChild(indextype);

    Element indexdata = doc.createElement("data");
    text = doc.createTextNode(filename + "Index.xml");
    indexdata.appendChild(text);
    indexview.appendChild(indexdata);

    root.appendChild(indexview);

    Element searchview = doc.createElement("view");

    Element searchname = doc.createElement("name");
    text = doc.createTextNode("Search");
    searchname.appendChild(text);
    searchview.appendChild(searchname);

    Element searchlabel = doc.createElement("label");
    text = doc.createTextNode("Search");
    searchlabel.appendChild(text);
    searchview.appendChild(searchlabel);

    Element searchtype = doc.createElement("type");
    text = doc.createTextNode("javax.help.SearchView");
    searchtype.appendChild(text);
    searchview.appendChild(searchtype);

    Element searchdata = doc.createElement("data");
    searchdata.setAttribute("engine", "com.sun.java.help.search.DefaultSearchEngine");
    text = doc.createTextNode("JavaHelpSearch");
    searchdata.appendChild(text);
    searchview.appendChild(searchdata);

    root.appendChild(searchview);

    doc.appendChild(root);
    return doc;
  }
}

