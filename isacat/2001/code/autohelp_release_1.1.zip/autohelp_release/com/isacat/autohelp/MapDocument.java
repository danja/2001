package com.isacat.autohelp;

import java.util.*;
import org.w3c.dom.*;

/**
 *  Description of the Class
 *
 * @author     danny
 * @created    23 January 2001
 */
public class MapDocument extends HelpDocument {

  // collection of mapping names to avoid duplicates
  private HashSet existingMapRefs = new HashSet();


  /**
   *  Constructor for the MapDocument object
   */
  public MapDocument() {
    createRoot("map");
  }


  /**
   *  Creates human-friendy references for the Map file
   *
   * @param  filename    filename sent
   * @param  currentDir  Description of Parameter
   * @return             friendly reference
   */
  public String makeMapRef(String filename, Directory currentDir) {
    // create a map reference for the urlString
    // starting with the cleaned-up name
    String ref = Directory.trimFileExt(filename);

    // get the current directory as an array
    ArrayList dirs = currentDir.getDirArray();
    int dirSize = dirs.size();
    int endDir = dirSize;

    // if the filename body is 'index'
    // use the name of the containing directory
    if ("index".equals(filename) && (dirSize > 0)) {
      ref = (String) dirs.get(dirSize - 1);
    }

    // if this ref has already been used, prepend the last directory name
    String dir;
    while (existingMapRefs.contains(ref)) {

      endDir--;
      if (endDir == -1) {
        ref = "Root" + ref;
        break;
      }
      dir = (String) dirs.get(endDir);
      ref = dir + ref;
    }

    // add to 'already used' list
    existingMapRefs.add(ref);

    return ref;
  }


  /**
   *  Adds an element to the map document
   *
   * @param  mapRef     map reference
   * @param  urlString  location of mapped item
   */
  public void addMapIDItem(String mapRef, String urlString) {
    Element mapID = createElement("mapID");
    mapID.setAttribute("target", mapRef);
    mapID.setAttribute("url", urlString);
    appendToRoot(mapID);
  }


  /**
   *  Writes document to file
   *
   * @param  helpTitle  title of document
   */
  public void writeXMLFile(String helpTitle) {
    super.writeXMLFile(helpTitle + "Map.xml");
  }

}
