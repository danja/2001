/**
 * @author     Danny Ayers
 * @created    01 April 2001
 * @version    1.1
 */

package com.isacat.autohelp;

import org.w3c.dom.Document;
import java.io.File;


/**
 * Automatically builds XML Files
 * in JavaHelp HelpSet format
 * based on filesystem contents
 *
 * see JavaHelp documention for
 * more information
 */
public class AutoHelp {
  private MapDocument mapDoc;
  private IndexDocument indexDoc;
  private TOCDocument tocDoc;

  private Document helpSet;

  // starting directory
  private File baseDir;
  private HelpHandler handler;

  public static int pageCount = 0;

  protected static String[] requiredFileExtns;
  protected static boolean filterFiles = true;

  private static String[] DEFAULT_FILE_EXTNS = {"htm", "html", "txt", "java", "xml", "xsd", "rdf"};

  private static boolean debug = false;
  // set to true for verbose output
  private final static String helpSetVersion = "1.0";

  // default title
  private static String helpTitle;
  // default to current dir
  private static String baseDirName = ".";

  /**
   *  Constructor for the AutoHelp object
   *
   * @param  baseDirName  starting directory (as String)
   */
  private AutoHelp(String baseDirName) {

    requiredFileExtns = DEFAULT_FILE_EXTNS;
    baseDir = new File(baseDirName);

    // check it can be read
    if (!baseDir.canRead()) {
      System.out.println("Can't read : " + baseDir);
      System.exit(1);
    }

    // a walker to go through directories
    DirWalker walker = new DirWalker();

    // the handler will respond to file & dir discovery
    handler = new HelpHandler();
    walker.setHandler(handler);

    handler.setBaseDir(baseDir);

    // initialize DOM trees
    System.out.println("\nInitializing trees...");
    initTrees();

    // recurse directories
    System.out.print("\nScanning directories");
    walker.walk(baseDir);

    // add the root directory to finish tree
    handler.handleDirectory(baseDir);

    // put Index together
    indexDoc.buildIndex();
    if (debug) {
      indexDoc.print();
    }

    // empty nodes correspond to empty directories
    System.out.print("\n\nRemoving references to empty folders");
    tocDoc.removeEmptyFolders();
    if (debug) {
      tocDoc.print();
    }

    // create HelpSet (.hs) file
    helpSet = HelpSet.makeHS(helpTitle);

    if (debug) {
      OutputDOM.print(helpSet);
    }
    // finalize DOM trees
    System.out.println("\n\nFinalizing trees...");
    finalizeTrees();
  }

  /**
   *  Shows additional information at console
   *
   * @param  ob  output is ob.toString()
   */
  private void debug(Object ob) {
    if (debug) {
      System.out.println(ob);
    }
  }


  /**
   *  Tree initialization
   */
  private void initTrees() {

    mapDoc = new MapDocument();
    indexDoc = new IndexDocument();
    tocDoc = new TOCDocument();

    handler.setMap(mapDoc);
    handler.setIndex(indexDoc);
    handler.setTOC(tocDoc);
  }


  /**
   *  Tree finalization
   */
  private void finalizeTrees() {
    String filePrefix = baseDirName + "/" + helpTitle;
    // output mapDoc to file
    mapDoc.writeXMLFile(filePrefix);
    System.out.println("\nWriting Map file :     " + filePrefix + "Map.xml");

    // output indexDoc to file
    indexDoc.writeXMLFile(filePrefix);
    System.out.println("Writing Index file : " + filePrefix + "Index.xml");

    // output tocDoc to file
    tocDoc.writeXMLFile(filePrefix);
    System.out.println("Writing TOC file :     " + filePrefix + "TOC.xml");

    // output HelpSet to file
    OutputDOM.file(helpSet, filePrefix + ".hs");
    System.out.println("Writing HelpSet file :    " + filePrefix + ".hs");
  }

  /**
   *  The main program for the AutoHelp class
   *
   * @param  args  title, starting directory
   */
  public static void main(String[] args) {

    if (args.length > 0) {
      helpTitle = args[0];
    }
    if (args.length > 1) {
      baseDirName = args[1];
    }

    if (args.length > 2) {
      if (args[2].equals("all")) {
        filterFiles = false;
      } else {
        requiredFileExtns = new String[args.length - 2];
        for (int i = 2; i < args.length; i++) {
          requiredFileExtns[i - 2] = args[i];
        }
      }
    }

    System.out.println("\n\nStarting from : " + baseDirName);
    new AutoHelp(baseDirName);
    System.out.println("\n" + pageCount + " pages indexed.");

  }
}
