package com.isacat.autohelp;

import java.util.*;
import org.w3c.dom.*;

/**
 *  Description of the Class
 *
 * @author     danny
 * @created    23 January 2001
 */
public class TOCDocument extends HelpDocument {

  private Stack stack = new Stack();


  /**
   *  Constructor for the TOCDocument object
   */
  public TOCDocument() {
    createRoot("toc");
  }


  /**
   *  Checks to see if the stack of elements is empty
   *
   * @return    The StackEmpty value
   */
  public boolean isStackEmpty() {
    return stack.size() == 0;
  }


  /**
   *  Returns the top element from the stack, leaving it in place
   *
   * @return    top of stack
   */
  public Element peekElement() {
    return (Element) stack.peek();
  }


  /**
   *  Description of the Method
   *
   * @return    Description of the Returned Value
   */
  public Element popElement() {
    return (Element) stack.pop();
  }


  /**
   *  Adds element to the top of the stack
   *
   * @param  element  element to stack
   */
  public void pushElement(Element element) {
    stack.push(element);
  }


  /**
   *  Returns size of element stack
   *
   * @return    number of elements in stack
   */
  public int stackSize() {
    return stack.size();
  }


  /**
   *  Creates new element and put it on the top of stack
   *
   * @param  name  name of element to create
   */
  public void pushNewElement(String name) {
    pushElement(createTOCElement(name));
  }


  /**
   *  Description of the Method
   *
   * @param  name  Description of Parameter
   * @return       Description of the Returned Value
   */
  public Element createTOCElement(String name) {
    Element newElement = createElement("tocitem");
    newElement.setAttribute("text", name);
    return newElement;
  }


  /**
   *  Create 'table of contents' element
   *
   * @param  target  mapped entry
   * @param  name    name displayed
   * @return         element created
   */
  public Element createTOCElement(String target, String name) {
    Element newElement = createTOCElement(name);
    newElement.setAttribute("target", target);
    return newElement;
  }

  public Element stepUp(int steps) {
    Element parentElement = null;
    Element childElement = null;
    for (int i = 0; i < steps; i++) {
      parentElement = popElement();

      // remove parent from stack
      debug("popped : " + parentElement.getTagName());

      childElement = parentElement;
      // get new parent
      if (!isStackEmpty()) {
        parentElement = popElement();
        debug("popped : " + parentElement.getTagName());
      } else {
        parentElement = getRoot();
      }
      // push parent back on stack
      pushElement(parentElement);
      debug("7*pushed : " + parentElement.getTagName());

      parentElement.appendChild(childElement);
      parentElement = childElement;
    }
    return parentElement;
  }


  /**
   *  Description of the Method
   */
  public void removeEmptyFolders() {
    NodeList nodes;
    boolean clean = false;
    do {
      nodes = getDocument().getElementsByTagName("tocitem");

      clean = true;
      int i;
      for (i = 0; i < nodes.getLength(); i++) {
        Element element = (Element) nodes.item(i);
        if (element == null) {
          continue;
        }
        if (element.hasAttribute("target")) {
          continue;
        }
        if (element.hasChildNodes()) {
          continue;
        }
// progress indicator
        System.out.print(".");
        clean = false;
        Element parent = (Element) element.getParentNode();
        debug("removing : " + element.getAttribute("text"));
        parent.removeChild(element);
      }

    } while (!clean);
  }


  /**
   *  Description of the Method
   *
   * @param  helpTitle  Description of Parameter
   */
  public void writeXMLFile(String helpTitle) {
    super.writeXMLFile(helpTitle + "TOC.xml");
  }
}
