// package com.wrox.javahelp;
package com.isacat.autohelp;

import java.io.*;

/**
 *  Interface for DirWalker Handlers
 *
 * @author     Danny Ayers
 * @created    04 January 2001
 * @version    1.0
 */

public interface DirHandler {

  /**
   *  Called when a new file is encountered
   *
   * @param  file  file found
   */
  public void handleFile(File file);


  /**
   *  Called when a new empty dir is encountered
   *
   * @param  file  directory found
   */
  public void handleEmptyDirectory(File file);


  /**
   *  Called when a new non-empty directory is encountered
   *
   * @param  file  directory found
   */
  public void handleDirectory(File file);
}
