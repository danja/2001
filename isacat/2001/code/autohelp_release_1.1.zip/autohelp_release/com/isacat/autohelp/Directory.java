package com.isacat.autohelp;

import java.util.*;
import java.io.*;
import java.text.*;

/**
 *  Model of file system directory
 *
 * @author     Danny Ayers
 * @created    01 April 2001
 */
public class Directory {
  private final boolean isNull;
  private String path = "";
  private final ArrayList dirArray = new ArrayList();
  private final String endDir = "";
  private int nDirs;
  private int baselength;


  /**
   *  Constructor for the Directory object
   */
  public Directory() {
    isNull = true;
  }


  /**
   *  Constructor for the Directory object
   *
   * @param  file     file & directory supplied
   * @param  basedir  base directory to which file is appended
   */
  public Directory(File file, File basedir) {

    baselength = (basedir.toString()).length();

    path = file.getPath().substring(baselength);

    // make slashes uniform
    path = path.replace('\\', '/');

    // make array of subdirectories
    StringTokenizer st = new StringTokenizer(path, "/");
    String dir;
    while (st.hasMoreTokens()) {
      dir = st.nextToken();
      dirArray.add(dir);
    }
    nDirs = dirArray.size();
    isNull = false;
  }


  /**
   *  Gets the Depth attribute of the Directory object
   *
   * @return    How many subdirectories?
   */
  public int getDepth() {
    return nDirs;
  }


  /**
   *  Gets the directory back as an array
   *
   * @return    array of subdirectories
   */
  public ArrayList getDirArray() {
    return dirArray;
  }


  /**
   *  Finds the difference between subdirectories i.e. this one and a sent one
   *
   * @param  dir  sent directory
   * @return      mismatch between directories
   */
  public int getMismatch(Directory dir) {
    // how many levels to take off sent dir to get up to common level?
    if (dir == null) {
      return 0;
    }
    if (isNull) {
      return dir.getDepth();
    }
    ArrayList al = dir.getDirArray();
    int sentsize = al.size();
    int min = sentsize < nDirs ? sentsize : nDirs;
    int match;
    for (match = 0; match < min; match++) {
      if (!al.get(match).equals(dirArray.get(match))) {
        break;
      }
    }
    return sentsize - match;
  }


  /**
   *  Test if there is a mismatch between this directory and the sent one
   *
   * @param  dir  directory to compare
   * @return      result of comparison
   */
  public boolean isMismatch(Directory dir) {
    return (getMismatch(dir) != 0);
  }


  ///////////////////// Utility methods
  /**
   *  Gets the Url attribute of the Directory object
   *
   * @param  filename  Description of Parameter
   * @return           The Url value
   */
  public String getUrlString(String filename) {
    String urlString = toString() + "/" + filename;
    // trim leading '/'
    if (urlString.startsWith("/")) {
      urlString = urlString.substring(1, urlString.length());
    }
    return urlString;
  }


  /**
   *  Gets the last subdirectory of the Directory object
   *
   * @return    ../subdir/subdir/endDir
   */

  public String makeNameFromDir() {
    // to avoid null pointers - should never happen
    if (nDirs == 0) {
      return "root is a dummy";
    }
    return (String) dirArray.get(nDirs - 1);
  }


  /**
   *  Gives a String representation of the path
   *
   * @return    directory path as String
   */
  public String toString() {
    if (path == null) {
      return null;
    }
    String string = path.toString();
    return string;
  }


  /**
   *  Makes human-friendly name from filename handles index.htm names by
   *  replacing with name of containing directory(ies)
   *
   * @param  filename  filename to humanize
   * @return           humanized form
   */
  public String makeNameFromFile(String filename) {

    String name = trimFileExt(filename);

    // if the filename without ext is 'index'
    if ("index".equals(name) && (nDirs > 0)) {

// use the name of the containing directory
      name = (String) getDirArray().get(nDirs - 1);
    }
    return name;
  }


  /**
   *  Checks if the file type is on the required list
   *
   * @param  filename  filename to check
   * @return           is it required?
   */
  public static boolean isRequiredFile(String filename) {
    if (!AutoHelp.filterFiles) {
      return true;
    }
    for (int i = 0; i < AutoHelp.requiredFileExtns.length; i++) {
      if (filename.endsWith("." + AutoHelp.requiredFileExtns[i])) {
        return true;
      }
    }
    return false;
  }

  /**
   *  Removes file extension e.g. 'filename.txt' ->'filename'
   *
   * @param  filename  String to trim
   * @return           trimmed String
   */
  public static String trimFileExt(String filename) {
    int dot = filename.lastIndexOf('.');
    if (dot == -1) {
      dot = filename.length();
    }
    String trim = filename.substring(0, dot);
    return trim;
  }
}

