<?xml version="1.0" encoding="UTF-8"?>

<helpset version="1.0">
  <title>Test</title>
  <maps>
    <homeID>top</homeID>
    <mapref location="TestMap.xml" />
  </maps>
  <view>
    <name>toc</name>
    <label>Table of Contents</label>
    <type>javax.help.TOCView</type>
    <data>TestTOC.xml</data>
  </view>
  <view>
    <name>index</name>
    <label>Index</label>
    <type>javax.help.IndexView</type>
    <data>TestIndex.xml</data>
  </view>
  <view>
    <name>Search</name>
    <label>Search</label>
    <type>javax.help.SearchView</type>
    <data engine="com.sun.java.help.search.DefaultSearchEngine">JavaHelpSearch</data>
  </view>
</helpset>

