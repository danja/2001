import java.sql.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    25 February 2001
 */
public class JDBCToXML {

  public final static String PROLOG = "<?xml version=\"1.0\"?>\n\n";
  public final static String OPEN_START = "<";
  public final static String SIMPLE_CLOSE = "/>";
  public final static String OPEN_END = "</";
  public final static String CLOSE = ">";
  public final static String NEWLINE = "\n";
  public final static String INDENT = "\t";
  
  private String docname = new String("document");
  private String recordname = new String("record");
  private String doctypeline;
  
  public void setRecordName(String s) {
    recordname = s;
  }
  
  public void setDocumentName(String s) {
    docname = s;
  }

  public void setDoctype(boolean external, String dtd) {
    doctypeline = "<!DOCTYPE " + docname + " ";
    doctypeline += external ? "SYSTEM" : "PUBLIC ";
    doctypeline += " \"" + dtd + "\">\n";
  }

  public String getXML(ResultSet rs) {

    StringBuffer xml = new StringBuffer(PROLOG + doctypeline);
    xml.append(NEWLINE + OPEN_START + docname + CLOSE);
    String data;

    try {
      ResultSetMetaData rsmeta = rs.getMetaData();
      int nfields = rsmeta.getColumnCount();

      
      while (rs.next()) {
        xml.append(NEWLINE + INDENT + OPEN_START + recordname + " ");
        for (int i = 1; i < nfields + 1; i++) {
          xml.append(rsmeta.getColumnName(i) + "=\"");
          data = XMLUtil.encodeChars(rs.getObject(i).toString());
          
          xml.append(data + "\" ");
        }
        xml.append(SIMPLE_CLOSE);
      }
      xml.append(NEWLINE + OPEN_END + docname + CLOSE);
    } catch (Exception e) {
      e.printStackTrace();
    }

    return xml.toString();
  }

}
