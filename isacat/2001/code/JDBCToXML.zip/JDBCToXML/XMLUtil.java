import java.util.*;

class XMLUtil{

      private static String escapeChar(char c){
         switch(c){
            case('<')  : return "&lt;";
            case('>')  : return "&gt;";  
            case('&')  : return "&amp;"; 
            case('\'') : return "&apos;"; 
            case('\"') : return "&quot;";                         
        } 
        return null;    
      }
      
      public static String encodeChars(String string){
      
         int length = string.length();
         char[] characters = new char[length];
         string.getChars(0, length, characters, 0);
         StringBuffer encoded = new StringBuffer();
         String escape;
         for(int i = 0;i<length;i++){
            escape = escapeChar(characters[i]);
            if(escape == null) encoded.append(characters[i]);
               else encoded.append(escape);
         }
         return encoded.toString();
      }
               
      public static void main(String[] args){
         String test = "AP = ' QT = \" AMP = & LT = < GT = > ";
         System.out.println(encodeChars(test));
      }
}
    

   
   
   
