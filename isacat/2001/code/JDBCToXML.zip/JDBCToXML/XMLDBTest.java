import java.sql.*;
import java.io.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    25 February 2001
 */
public class XMLDBTest {

  String driver = "org.gjt.mm.mysql.Driver";
  String database = "jdbc:mysql://localhost:3306/iou";
  String user = "wrox";
  String password = "xorw";

  public static void main(String[] args) {
    new XMLDBTest();
  }
  
  public XMLDBTest() {
    ResultSet rs = null;
    try {
      Class.forName(driver);
      Connection conn = DriverManager.getConnection(database, user, password);
      Statement s = conn.createStatement();
      rs = s.executeQuery("SELECT * FROM addresses");
    } catch (Exception e) {
      e.printStackTrace();
    }
    JDBCToXML jtox = new JDBCToXML();
    jtox.setDocumentName("addressbook");
    jtox.setDoctype(true, "addresses.dtd");
    jtox.setRecordName("entry");
    saveString("jdbctest.xml", jtox.getXML(rs));
     
  }
  
  public void saveString(String filename, String string) {

    FileOutputStream outstream;
    BufferedOutputStream buffer;
    int length;
    byte[] bytes;
    try {
      outstream = new FileOutputStream(filename);
      buffer = new BufferedOutputStream(outstream);
      bytes = string.getBytes();
      length = string.length();
      for (int i = 0; i < length; i++) {
        buffer.write(bytes[i]);
      }
      buffer.close();
      outstream.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
