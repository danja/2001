import java.util.*;
import java.io.*;
import org.w3c.dom.*;

import javax.xml.parsers.*;

import org.apache.crimson.tree.*; // Crimson
// import org.apache.xml.serialize.*; // Xerces


/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    05 March 2001
 */
public class DirDocument {

  public Document doc;
  //Stack stack = new Stack();


  public DirDocument() {
    DocumentBuilderFactory factory = null;
    DocumentBuilder builder = null;

    try {
      factory = DocumentBuilderFactory.newInstance();
      builder = factory.newDocumentBuilder();
    } catch (Exception e) {
      System.out.println(e);
    }
    doc = builder.newDocument();
   // Element root = doc.createElement("filesystem");
    Element root = doc.createElement("filesystem");
    doc.appendChild(root);
  }






 public Element getRoot() {
    return doc.getDocumentElement();
  }
  
  public Element createElement(String tagName) {
    return doc.createElement(tagName);
  }
  
  public void writeXMLFile(String name) {

    try {


      File outputFile = new File(name);
      FileOutputStream fos = new FileOutputStream(outputFile);
      XmlDocument xdoc = (XmlDocument) doc;      
      xdoc.write(fos);
      fos.close();
      

    } catch (Exception e) {
      System.out.println(e);
    }
  }
  /* Xerces version
  public static void writeXMLFile(String name, Document doc) {

    try {
			File outputFile = new File(name);
			FileOutputStream fos = new FileOutputStream(outputFile);

			OutputFormat format = new OutputFormat(doc);
			// creates a format appropriate to doc
			format.setIndent(3);

			// will write to a String
			XMLSerializer serial = new XMLSerializer(fos, format);
			// build serializer
			serial.asDOMSerializer();
			// as a DOM Serializer
			serial.serialize(doc.getDocumentElement());
			// serialize it out

			fos.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
  */
}
