import java.util.*;
import java.io.*;
import java.text.*;

/**
 *  Model of file system directory 
 *
 *@author     Danny Ayers 
 *@created    04 January 2001 
 */
public class Directory {
//	boolean isNull;
	String path = "";
	ArrayList dirArray = new ArrayList();
	String endDir = "";
	int ndirs = 0;
//	int baselength = 0;


   public Directory(){}
	/**
	 *  Constructor for the Directory object 
	 *
	 *@param  file     file & directory supplied 
	 *@param  basedir  base directory to which file is appended 
	 */
	public Directory(File file, File basedir) {

		int baselength = (basedir.toString()).length();

		path = file.getPath().substring(baselength);

		// make slashes uniform
		path = path.replace('\\', '/');

		// make array of subdirectories
		StringTokenizer st = new StringTokenizer(path, "/");
		String dir;
		while (st.hasMoreTokens()) {
			dir = st.nextToken();
			dirArray.add(dir);
		}
		ndirs = dirArray.size();
	//	isNull = false;
	}


	/**
	 *  Gets the Depth attribute of the Directory object 
	 *
	 *@return    How many subdirectories? 
	 */
	 
	public int getDepth() {
		return ndirs;
	}


	 
	public ArrayList getDirArray() {
		return dirArray;
	}


	/**
	 *  Finds the difference between subdirectories 
	 *
	 *@param  dir  sent directory 
	 *@return      mismatch between directories 
	 */
	public int getMismatch(Directory dir) {
		// how many levels to take off sent dir to get down to common level?
	//	if (dir == null) return 0;
	

		ArrayList al = dir.getDirArray();
		int sentsize = al.size();
		int min = sentsize < ndirs ? sentsize : ndirs;
		int match;
		for (match = 0; match < min; match++) {
			if (!al.get(match).equals(dirArray.get(match))) {
				break;
			}
		}
		return sentsize - match;
	}


	/**
	 *  Gets the Mismatch attribute of the Directory object 
	 *
	 *@param  dir  Description of Parameter 
	 *@return      The Mismatch value 
	 */
	 
	public boolean isMismatch(Directory dir) {
		return (getMismatch(dir) != 0);
	}



	/**
	 *  Gets the last subdirectory of the Directory object 
	 *
	 *@return    ../subdir/subdir/endDir 
	 */

	public String getName() {

		return (String) dirArray.get(ndirs - 1);
	}




}

