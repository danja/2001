// package com.wrox.javahelp;
/*
 * Recursively walks file system
 * directory tree, calling methods
 * in Handler as files/directories
 * are encountered
 *
 *
 */

import java.io.*;
import java.util.*;
import java.text.*;


public class DirWalker {

  private DirHandler handler = null;

  public void setHandler(DirHandler dh) {
    handler = dh;
  }




  /**
   *  Walks the directory
   *
   * @param  file  directory to walk
   */
  public void walk(File file) {

    if (file.isDirectory()) {
      handler.dirElement(file);

      Object[] filenamelist = file.list();

      // files in this dir
      if (filenamelist.length > 0) {

        TreeMap sorted = new TreeMap(new FileDirComparison());
        //new FileDirComparison()

        for (int i = 0; i < filenamelist.length; i++) {
          sorted.put(new File(file, (String) filenamelist[i]), filenamelist[i]);
        }

        Object[] filelist = sorted.keySet().toArray();
        filenamelist = sorted.values().toArray();

        for (int i = 0; i < filenamelist.length; i++) {

          // ignore . and ..
          File check = (File) filelist[i];
          if (check.equals(file)) {
            continue;
          }
          if (check.equals(file.getParentFile())) {
            continue;
          }

          walk((File) filelist[i]);
        }
      } else {
        handler.emptyDirElement(file);
      }
    } else {
      handler.fileElement(file);
    }

  }

// Returns a negative integer, zero, or a positive integer as the first argument is less than, equal to, or greater than the second.
// Puts files ahead of directories, otherwise alphabetical

  /**
   *  Description of the Class
   *
   * @author     Danny Ayers
   * @created    05 March 2001
   */
  class FileDirComparison implements Comparator {

    public int compare(Object a, Object b) {
      File filea = (File) a;
      File fileb = (File) b;
      if (filea.isDirectory() && fileb.isFile()) {
        return -1;
      }
      if (filea.isFile() && fileb.isDirectory()) {
        return 1;
      }
      return filea.toString().compareTo(fileb.toString());
    }


    public boolean equals(Object ob) {
      return equals(ob);
    }

  }

}
