import java.io.*;

public interface DirHandler {

  /**
   *  Called when a new file is encountered
   *
   * @param  file  file found
   */
  public void fileElement(File file);


  /**
   *  Called when a new empty dir is encountered
   *
   * @param  file  directory found
   */
  public void emptyDirElement(File file);


  /**
   *  Called when a new non-empty directory is encountered
   *
   * @param  file  directory found
   */
  public void dirElement(File file);
}
