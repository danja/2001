
import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.xml.sax.*;

/**
 * @author     Danny Ayers
 * @created    03 January 2001
 * @version    1.0
 */

public class DirToXML {

  static String title = "dir.xml";

  public static void main(String[] args) {

    // default to current dir
    String basedirname = ".";

    if (args.length > 0) {
      title = args[0];
    }
    if (args.length > 1) {
      basedirname = args[1];
    }
    System.out.println("\nStarting from : " + basedirname);
    new DirToXML(basedirname);
    System.out.println("\nDone.");
  }
  
  public DirToXML(String basedirname) {
    File basedir = new File(basedirname);

    // check it can be read
    if (!basedir.canRead()) {
      System.out.println("Can't read : " + basedir);
      System.exit(1);
    }

    // a walker to go through directories
    DirWalker dw = new DirWalker();

    // the handler will respond to file & dir discovery
    Handler  handler = new Handler();
    dw.setHandler(handler);

    handler.setBaseDir(basedir);

    // initialize DOM trees
    DirDocument dirdoc = new DirDocument();
    handler.setDocument(dirdoc);

    // recurse directories
    dw.walk(basedir);

    // add the root directory to finish tree
    handler.dirElement(basedir);

 //   dirdoc.removeNonJava();

    dirdoc.writeXMLFile(title);
  }





}
