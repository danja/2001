import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;

import org.xml.sax.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    05 March 2001
 */
public class Handler implements DirHandler {

  Stack stack = new Stack();
  DirDocument doc;
  Directory lastDir = new Directory();

  // starting directory
  File basedir;



  public void setDocument(DirDocument dirdoc) {
    doc = dirdoc;
  }

  public void setBaseDir(File dir) {
    basedir = dir;

  }

  public boolean isStackEmpty() {
    return stack.size() == 0;
  }



  public void fileElement(File file) {
    // the directory in which this file occurs
    Directory currentDir = new Directory(new File(file.getParent()), basedir);

    // if it has changed dir here need to trap it & call handler
    if (currentDir.isMismatch(lastDir))   dirElement(file.getParentFile());

    Element parentElement = (Element) stack.peek();

    Element childElement = doc.createElement("file");
    
    childElement.setAttribute("name", file.getName());
    
        parentElement.appendChild(childElement);
  }


  public void dirElement(File file) {

    // append base
    Directory currentDir = new Directory(file, basedir);
    Element childElement = null;
    Element parentElement = null;

    

// walk down to common level popping and writing
    int downMismatch = currentDir.getMismatch(lastDir);

    for (int i = 0; i < downMismatch; i++) {
    
    childElement = (Element) stack.pop();

      // get new parent
      if (!isStackEmpty()) {
        parentElement = (Element) stack.pop();

      } else {
        parentElement = doc.getRoot();
      }

      stack.push(parentElement);

      parentElement.appendChild(childElement);

      parentElement = childElement;

    }

    if (lastDir.isMismatch(currentDir)) {
      // walk up to new level pushing and writing
      for (int i = 0; i < lastDir.getMismatch(currentDir) - 1; i++) {
        parentElement.appendChild(childElement);
        stack.push(parentElement);
        parentElement = childElement;
      }


      Element newElement = doc.createElement("directory");

      newElement.setAttribute("name", currentDir.getName());
      stack.push(newElement);
    }
    lastDir = currentDir;
  }

  public void emptyDirElement(File file) {
  }
}

