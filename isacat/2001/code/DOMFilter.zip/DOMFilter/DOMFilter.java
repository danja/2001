import org.w3c.dom.*;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    07 March 2001
 */
public class DOMFilter {

  public DOMFilter() {
    Document doc = DOMFile.readXMLFile("input.xml");
    doc = removeNonJava(doc);
    DOMFile.writeXMLFile("output.xml", doc);
  }


  public Document removeNonJava(Document doc) {
    NodeList nodes = doc.getElementsByTagName("file");
    boolean isJava;
    do {
      isJava = false;
      for (int i = 0; i < nodes.getLength(); i++) {

        Element element = (Element) nodes.item(i);

        if (element == null) {
          continue;
        }

        if (!element.getAttribute("name").endsWith(".java")) {
          isJava = true;
          Element parent = (Element) element.getParentNode();
          parent.removeChild(element);
        }
      }
    } while (isJava == true);
    return doc;
  }

  public static void main(String args[]) {
    new DOMFilter();
  }

}
