import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;
import org.apache.crimson.tree.*; // crimson
// import org.apache.xml.serialize.*; Xerces

import java.io.*;


/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    07 March 2001
 */
public class DOMFile {


  public static Document readXMLFile(String filename) {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = null;
    try {
      builder = factory.newDocumentBuilder();
    } catch (Exception e) {
      System.out.println(e);
    }

    Document doc = null;
    try {
      doc = builder.parse(new File(filename));
    } catch (Exception e) {
      System.out.println(e);
    }
    return doc;
  }

  public static void writeXMLFile(String name, Document doc) {

    try {

      File outputFile = new File(name);
      FileOutputStream fos = new FileOutputStream(outputFile);
      XmlDocument xdoc = (XmlDocument) doc;
      xdoc.write(fos);
      fos.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
  /* Xerces version
  public static void writeXMLFile(String name, Document doc) {

    try {
			File outputFile = new File(name);
			FileOutputStream fos = new FileOutputStream(outputFile);

			OutputFormat format = new OutputFormat(doc);
			// creates a format appropriate to doc
			format.setIndent(3);

			// will write to a String
			XMLSerializer serial = new XMLSerializer(fos, format);
			// build serializer
			serial.asDOMSerializer();
			// as a DOM Serializer
			serial.serialize(doc.getDocumentElement());
			// serialize it out

			fos.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
  */
}
