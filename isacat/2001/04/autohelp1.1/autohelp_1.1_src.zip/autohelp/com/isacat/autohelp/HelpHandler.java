/**
 * @author     Danny Ayers
 * @created    03 January 2001
 * @version    1.0
 */

package com.isacat.autohelp;

import org.w3c.dom.Element;
import java.io.File;


/**
 * Handles callbacks from directory walker
 * creates DOM elements for the three HelpSet documents
 */
public class HelpHandler implements DirHandler {

  MapDocument mapDoc;
  IndexDocument indexDoc;
  TOCDocument tocDoc;
  Element tocRoot = null;

  // remember the last directory visited
  Directory lastDir = new Directory();

  // starting directory
  File basedir;

  private static boolean debug = false;

  // project title
  private static String helpTitle = "Title";

  /**
   *  Constructor for the HelpHandler object
   */
  public HelpHandler() {
  }


  /**
   *  Sets the Map document
   *
   * @param  mapDoc  map document to be populated
   */
  public void setMap(MapDocument mapDoc) {
    this.mapDoc = mapDoc;
  }


  /**
   *  Sets the Index document
   *
   * @param  indexDoc  index document to be populated
   */
  public void setIndex(IndexDocument indexDoc) {
    this.indexDoc = indexDoc;
  }


  /**
   *  Sets the TOC document
   *
   * @param  tocDoc  toc document to be populated
   */
  public void setTOC(TOCDocument tocDoc) {
    this.tocDoc = tocDoc;
  }


  /**
   *  Sets the BaseDir attribute of the HelpHandler object
   *
   * @param  dir  The new BaseDir value
   */
  public void setBaseDir(File dir) {
    basedir = dir;

  }


  /**
   *  Gets the BaseDir attribute of the HelpHandler object
   *
   * @return    The BaseDir value
   */
  public File getBaseDir() {
    return basedir;
  }


  /**
   *  Shows additional information at console
   *
   * @param  ob  output is ob.toString()
   */
  public void debug(Object ob) {
    if (debug) {
      System.out.println(ob);
    }
  }


  /**
   *  Responds to file discovery
   *
   * @param  file  file as passed from tree walker
   */
  public void handleFile(File file) {
    // the directory in which this file occurs
    if (!Directory.isRequiredFile(file.toString())) {
      return;
    }
    AutoHelp.pageCount++;
    Directory currentDir = new Directory(new File(file.getParent()), basedir);

    // if it has changed dir here need to trap it
    if (currentDir.isMismatch(lastDir)) {
      // send as a directory change
      handleDirectory(file.getParentFile());
    }
    String filename = file.getName();

    // discount non-HTML / non-text
    if (!Directory.isRequiredFile(filename)) {
      return;
    }

    // creates a reference for the Map file to this file
    String mapRef = mapDoc.makeMapRef(filename, currentDir);

    mapDoc.addMapIDItem(mapRef, currentDir.getUrlString(filename));

    String name = currentDir.makeNameFromFile(filename);

    // put the entry <indexitem target="[mapRef]" text="[text]"> into indexDoc array
    indexDoc.putNewItem(mapRef, name);
    debug(mapRef + " " + name);

    Element parentElement = tocDoc.peekElement();

    Element childElement = tocDoc.createTOCElement(mapRef, name);
    parentElement.appendChild(childElement);
  }


  /**
   *  Responds to directory discovery
   *
   * @param  file  directory found
   */
  public void handleDirectory(File file) {
// if (tocDoc.isStackEmpty()) return;
    Element childElement = null;
    Element parentElement = null;

    debug("Directory---------------------------------");
    if (file == basedir) {
      debug("BASEDIR");
    }
    // append base
    Directory currentDir = new Directory(file, basedir);

    debug("   lastDir = " + lastDir);
    debug("currentDir = " + currentDir);

    // initial value of child is top element in stack
    if (!tocDoc.isStackEmpty()) {
      childElement = tocDoc.peekElement();
      debug("peeked : " + childElement.getTagName());
    }
    parentElement = tocDoc.stepUp(currentDir.getMismatch(lastDir));

    if (lastDir.isMismatch(currentDir)) {
      // push onto stack
      tocDoc.pushNewElement(currentDir.makeNameFromDir());
    }
    lastDir = currentDir;
  }


  /**
   *  Responds to empty directory discovery
   *
   * @param  file  directory found
   */
  public void handleEmptyDirectory(File file) {
    // nothing needed
    debug(file.getName());
  }

}

