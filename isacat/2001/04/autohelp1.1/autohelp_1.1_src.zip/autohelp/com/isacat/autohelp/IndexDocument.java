package com.isacat.autohelp;

import org.w3c.dom.*;
import java.util.*;

/**
 *  Description of the Class
 *
 * @author     danny
 * @created    23 January 2001
 */
public class IndexDocument extends HelpDocument {

  // map to contain name, mapRef pairs & automatically sort
  private TreeMap indexArray = new TreeMap();

  /**
   *  Constructor for the IndexDocument object
   */
  public IndexDocument() {
    createRoot("index");
  }

  /**
   *  Add map reference/name pair to list
   *
   * @param  mapRef  map reference
   * @param  name    indexed name
   */
  public void putNewItem(String mapRef, String name) {

    // pad to make identical names different
    while (indexArray.containsKey(name)) {
      name += " ";
    }
    indexArray.put(name, mapRef);
  }

  /**
   *  Creates the DOM index document from the list of map reference/name pairs
   */
  public void buildIndex() {
    Element indexElement;
    String mapRef;
    String name;
    for (Iterator i = indexArray.keySet().iterator(); i.hasNext(); ) {
      name = (String) i.next();
      mapRef = (String) indexArray.get(name);

      indexElement = createElement("indexitem");
      indexElement.setAttribute("target", mapRef);
      indexElement.setAttribute("text", name);
      // put the entry <indexitem target="[ref]" text="[index]"> into index
      appendToRoot(indexElement);
    }
  }

  /**
   *  Write to file
   *
   * @param  helpTitle  title
   */
  public void writeXMLFile(String helpTitle) {
    super.writeXMLFile(helpTitle + "Index.xml");
  }

}
