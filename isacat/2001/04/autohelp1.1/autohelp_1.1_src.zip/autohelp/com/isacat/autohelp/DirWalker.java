/**
 * @author     Danny Ayers
 * @created    04 January 2001
 * @version    1.0
 */

package com.isacat.autohelp;

import java.io.*;
import java.util.*;
import java.text.*;


/**
 * Recursively walks file system
 * directory tree, calling methods
 * in Handler as files/directories
 * are encountered
 */
public class DirWalker implements DirHandler {

  private DirHandler handler = null;

  private static boolean debug = false;


  /**
   *  Constructor for the DirWalker object
   */
  public DirWalker() {
    setHandler(this);
    // default is itself, for test
  }


  /**
   *  Sets the Handler attribute of the DirWalker object
   *
   * @param  dh  The new Handler value
   */
  public void setHandler(DirHandler dh) {
    handler = dh;
  }


  /**
   *  Provides extra console messages
   *
   * @param  ob  message to output
   */
  public void debug(Object ob) {
    if (debug) {
      System.out.println(ob);
    }
  }


  /**
   *  Walks the directory
   *
   * @param  file  directory to walk
   */
  public void walk(File file) {

    if (file.isDirectory()) {
// progress indicator
      System.out.print(".");
      handler.handleDirectory(file);

      Object[] filenamelist = file.list();

      // files in this dir
      if (filenamelist.length > 0) {

        TreeMap sorted = new TreeMap(new FileDirComparison());

        for (int i = 0; i < filenamelist.length; i++) {
          sorted.put(new File(file, (String) filenamelist[i]), filenamelist[i]);
        }

        Object[] filelist = sorted.keySet().toArray();

        filenamelist = sorted.values().toArray();

        for (int i = 0; i < filenamelist.length; i++) {

          // ignore . and ..
          File check = (File) filelist[i];
          if (debug) {
            System.out.println("filelist " + check);
          }
          if (check.equals(file)) {
            continue;
          }
          if (check.equals(file.getParentFile())) {
            continue;
          }

          walk((File) filelist[i]);
        }
      } else {
        handler.handleEmptyDirectory(file);
      }
    } else {
      handler.handleFile(file);
    }

  }

  public void handleFile(File file) {
    System.out.println("File : " + file.getName());
  }

  public void handleEmptyDirectory(File file) {
    System.out.println("Empty Dir : " + file.getName());
  }

  public void handleDirectory(File file) {
    System.out.println("Directory : " + file.getName());
  }

  /**
   *  The main program for the DirWalker class for testing purposes.
   *
   * @param  args  starting directory
   */
  public static void main(String[] args) {
    // Main method for testing purposes
    String basedirname = ".";
    // default to current dir
    if (args.length > 0) {
      basedirname = args[0];
    }
    System.out.println("Basedir : " + basedirname);

    File basedir = new File(basedirname);
    if (!basedir.canRead()) {
      System.out.println("Can't read : " + basedir);
      System.exit(1);
    }
    DirWalker dw = new DirWalker();
    //	dw.setHandler(this);
    dw.walk(basedir);
  }


  /**
   *  Description of the Class
   *
   * @author     Danny Ayers
   * @created    29 March 2001 Used to sort discovered files/directories Puts
   *      files ahead of directories, otherwise alphabetical
   */
  class FileDirComparison implements Comparator {

    /**
     *  Returns a negative integer, zero, or a positive integer as the first
     *  argument is less than, equal to, or greater than the second. Puts files
     *  ahead of directories, otherwise alphabetical
     *
     * @param  a  first argument
     * @param  b  second argument
     * @return    result of comparison
     */
    public int compare(Object a, Object b) {
      File filea = (File) a;
      File fileb = (File) b;
      if (filea.isDirectory() && fileb.isFile()) {
        return -1;
      }
      if (filea.isFile() && fileb.isDirectory()) {
        return 1;
      }
      return filea.toString().compareTo(fileb.toString());
    }

    /**
     *  calls superclass equals() method
     *
     * @param  ob  Description of Parameter
     * @return     Description of the Returned Value
     */
    public boolean equals(Object ob) {
      return equals(ob);
    }

  }
}
