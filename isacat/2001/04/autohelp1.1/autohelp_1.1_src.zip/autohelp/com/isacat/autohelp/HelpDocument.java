package com.isacat.autohelp;

import java.util.*;

import org.w3c.dom.*;
import javax.xml.parsers.*;

/**
 *  Base class for HelpSet documents
 *
 * @author     danny
 * @created    23 January 2001
 */
public class HelpDocument {

  /**
   *  DOM document
   */
  public Document doc;

  // set to true for verbose output
  private static boolean debug = false;

  private final static String HSVERSION = "1.0";


  /**
   *  Constructor for the HelpDocument object builds empty DOM document
   */
  public HelpDocument() {

    DocumentBuilderFactory factory = null;
    DocumentBuilder builder = null;

    try {
      factory = DocumentBuilderFactory.newInstance();
      builder = factory.newDocumentBuilder();
    } catch (Exception e) {
      System.out.println(e);
    }
    doc = builder.newDocument();
  }


  /**
   *  Wrapper for doc.getElementsByTagName(tagName)
   *
   * @param  tagName  Description of Parameter
   * @return          The ElementsByTagName value
   */
  public NodeList getElementsByTagName(String tagName) {
    return doc.getElementsByTagName(tagName);
  }


// Additional helpers
  /**
   *  Gets the DOM document
   *
   * @return    the document
   */
  public Document getDocument() {
    return doc;
  }


  /**
   *  Gets the root element of DOM document
   *
   * @return    The root value
   */
  public Element getRoot() {
    return doc.getDocumentElement();
  }


// Methods from Document/Node
  /**
   *  Wrapper for doc.appendChild(child)
   *
   * @param  child  child element
   * @return        child element
   */
  public Node appendChild(Node child) {
    doc.appendChild(child);
    return child;
  }


  /**
   *  Wrapper for doc.createElement(tagName)
   *
   * @param  tagName  name of tag
   * @return          created element
   */
  public Element createElement(String tagName) {
    //	System.out.println("TAGNAME = "+tagName);
    return doc.createElement(tagName);
  }


  /**
   *  Helper to append child to this document's root element
   *
   * @param  child  child to append
   * @return        child element
   */
  public Node appendToRoot(Node child) {
    getRoot().appendChild(child);
    return child;
  }


  /**
   *  Creates root element (with version attribute)
   *
   * @param  docType  whether toc, index or map
   */
  public void createRoot(String docType) {
    Element root = doc.createElement(docType);
    root.setAttribute("version", HSVERSION);
    appendChild(root);
  }


  /**
   *  Call OutputDOM to write document to XML file
   *
   * @param  title  title of document
   */
  public void writeXMLFile(String title) {
    OutputDOM.file(getDocument(), title);
  }


  /**
   *  Call OutputDOM to write document to console
   */
  public void print() {
    OutputDOM.print(getDocument());
  }


  /**
   *  For optionally more verbose console output
   *
   * @param  ob  object to print (as String)
   */
  protected void debug(Object ob) {
    if (debug) {
      System.out.println(ob);
    }
  }
}
