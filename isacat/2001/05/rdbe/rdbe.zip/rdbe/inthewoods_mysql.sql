CREATE TABLE food (id INT PRIMARY KEY, foodtype VARCHAR(10));
INSERT INTO food VALUES (1,'kapok');
INSERT INTO food VALUES (2,'honey');
INSERT INTO food VALUES (3,'campers');

CREATE TABLE bears (id INT PRIMARY KEY, name VARCHAR(10), food INT);
INSERT INTO bears VALUES (1,'pooh', 2);
INSERT INTO bears VALUES (2,'teddy', 1);
INSERT INTO bears VALUES (3,'grizzly', 3);

SELECT bears.name FROM bears WHERE id='2'

SELECT bears.name FROM bears WHERE bears.name LIKE '%y'

SELECT food.foodtype FROM food INNER JOIN bears ON (bears.food=food.id) WHERE bears.name = 'grizzly'

