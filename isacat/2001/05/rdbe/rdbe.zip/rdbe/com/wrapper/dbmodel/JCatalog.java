// start of JCatalog.java
package com.wrapper.dbmodel;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;

import com.hp.hpl.mesa.rdf.jena.vocabulary.RDF;

import com.wrapper.vocabulary.RDBE;

public class JCatalog extends JDataset {
  Resource resource = null;

  public JCatalog(JDatabase database, String name) {
    super(database, name);
  }

  public Resource asResource(Model model) {
    if (resource != null) {
      return resource;
    }

    try {
      resource = model.createResource(database.getBaseUri()+"catalog." + name);
      resource.addProperty(RDF.type, RDBE.Catalog);
      resource.addProperty(RDBE.name, name);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return resource;
  }
}// start of JCatalog.java
