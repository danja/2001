// start of JDatabase.java
package com.wrapper.dbmodel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.Map;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import java.util.Iterator;

import com.wrapper.util.TypesUtil;

public class JDatabase {

  private String name = null;
  private Connection connection = null;

  private Map attributes = null;
  private List catalogNames = null;
  private List catalogs = null;
  private List schemaNames = null;
  private List schemas = null;
  private DatabaseMetaData metadata = null;
  
  private static String baseUri;

  public JDatabase() {
  }

  public void setConnection(Connection connection) {
    this.connection = connection;
  }
  
  public void setBaseUri(String baseUri){
      this.baseUri = baseUri;
  }

  public String getBaseUri(){
      return baseUri;
  }
  
  public void setCatalog(String catalogName) {
    try {
      connection.setCatalog(catalogName);
    } catch (SQLException sqle) {
      sqle.printStackTrace();
    }
  }

  public Connection getConnection() {
    return connection;
  }

  public DatabaseMetaData getMetaData() {
    try {
      if (metadata == null) {

        metadata = connection.getMetaData();
      }
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
    return metadata;
  }

  public List getCatalogs() {
    if (catalogs != null) {
      return catalogs;
    }
    ResultSet rsCatalogs = null;
    JCatalog catalog;
    catalogs = new Vector();
    try {
      rsCatalogs = getMetaData().getCatalogs();
      while (rsCatalogs.next()) {
        catalog = new JCatalog(this, rsCatalogs.getString(1));
        catalogs.add(catalog);
      }
    } catch (SQLException sqle) {
      catalogs = null;
      sqle.printStackTrace();
    }
    return catalogs;
  }

  public JCatalog getCatalog(String named) {
    List catalogs = getCatalogs();

    if (catalogs == null) {
      return null;
    }
    JCatalog catalog;

    for (Iterator i = catalogs.iterator(); i.hasNext(); ) {
      catalog = (JCatalog) i.next();
      if (catalog.getName().equals(named)) {
        return catalog;
      }
    }
    return null;
  }

  public List getSchemas() {
    if (schemas != null) {
      return schemas;
    }
    String schemaName;
    schemas = new Vector();
    ResultSet rsSchemas = null;
    JSchema schema;
    try {
      rsSchemas = getMetaData().getSchemas();
      while (rsSchemas.next()) {
        schema = new JSchema(this, rsSchemas.getString(1));
        schemas.add(schema);

      }
    } catch (SQLException sqle) {
      schemas = null;
      sqle.printStackTrace();
    }
    return schemas;
  }

  public JSchema getSchema(String named) {
    List schemas = getSchemas();

    if (schemas == null) {
      return null;
    }
    String schemaName;
    JSchema schema;
    for (Iterator i = schemas.iterator(); i.hasNext(); ) {
        schema = (JSchema) i.next();
      if (schema.getName().equals(named)) {
        return schema;
      }
    }    
    return null;
  }



  public List getTables(String catalog, String schemaPattern, String tablePattern, String[] types) {
    JTable table;
    List tables = new Vector();
    ResultSet rsTables;
    try {
      setCatalog(catalog);
      rsTables = getMetaData().getTables(catalog, schemaPattern, tablePattern, types);
      Object object;
      String name = "unnamed";
      String catalogName = "unnamed";
      String schemaName = "unnamed";
      String type = "unnamed"; 
      
      while (rsTables.next()) {
        object = rsTables.getObject(1);  
        if(object != null) catalogName = object.toString();
        table.setCatalogName(catalogName);

        object = rsTables.getObject(2);  
        if(object != null) schemaName = object.toString();
        table.setSchemaName(schemaName);  

        object = rsTables.getObject(3);
        if(object != null) name = object.toString();
        table = new JTable(this, name);
       
        object = rsTables.getObject(4);  
        if(object != null) type = object.toString();
        table.setType(type);         
        tables.add(table);
      }
    } catch (SQLException sqle) {
      tables = null;
      sqle.printStackTrace();
    }
    return tables;
  }

  public List getTables() {
    return getTables(null, "%", "%", null);
  }

  public List getColumns(String catalog, String schemaPattern, String tablePattern, String columnPattern) {
    JColumn column;
    List columns = new Vector();
    List primaryKeys;
    Map foreignKeys;
    ResultSet rsColumns;
    try {
      setCatalog(catalog);
      rsColumns = getMetaData().getColumns(catalog, schemaPattern, tablePattern, columnPattern);
      primaryKeys = getPrimaryKeys(catalog, schemaPattern, tablePattern);
      foreignKeys = getForeignKeys(catalog, schemaPattern, tablePattern);
      String typeString;
      String qName;
      while (rsColumns.next()) {
        column = new JColumn(this, rsColumns.getString(4));

        typeString = TypesUtil.getTypeAsString((int) rsColumns.getShort(5));
        column.setType(typeString);
        column.setColumnSize(rsColumns.getInt(7));
        column.setTableName(rsColumns.getString(3));
        qName = column.getTableName() + "." + column.getName();
        System.out.println("foreignKeys.keySet() " + foreignKeys.keySet());
        if (primaryKeys.contains(qName)) {
          column.setKey("primary");
        } else
        //     System.out.println("qName "+qName+" get(qName) "+foreignKeys.get(qName)+"  foreignKeys.keySet() "+foreignKeys.keySet());

          if (foreignKeys.keySet().contains(qName)) {

          column.setKey(foreignKeys.get(qName).toString());
          //   System.out.println("+++qName "+qName+" get(qName) "+foreignKeys.get(qName));
        }
        columns.add(column);
      }
    } catch (SQLException sqle) {
      columns = null;
      sqle.printStackTrace();
    }
    return columns;
  }

  public List getColumns() {
    return getColumns(null, "%", "%", "%");
  }

  public List getPrimaryKeys(String catalog, String schema, String table) {

    List primaryKeys = new Vector();
    ResultSet rsKeys;
    try {
      setCatalog(catalog);
      rsKeys = getMetaData().getPrimaryKeys(catalog, schema, table);

      while (rsKeys.next()) {
        primaryKeys.add(rsKeys.getString(3) + "." + rsKeys.getString(4));
      }

    } catch (SQLException sqle) {
      primaryKeys = null;
      sqle.printStackTrace();
    }
    return primaryKeys;
  }

  public Map getForeignKeys(String catalog, String schema, String table) {

    Map foreignKeys = new Hashtable();
    ResultSet rsKeys;
    Object mapKey;
    Object mapValue;
    try {
      setCatalog(catalog);
      rsKeys = getMetaData().getImportedKeys(catalog, schema, table);

      while (rsKeys.next()) {
        mapValue = rsKeys.getString(3) + "." + rsKeys.getString(4);
        mapKey = rsKeys.getString(7) + "." + rsKeys.getString(8);
        System.out.println("******" + mapKey + "   " + mapValue);

        foreignKeys.put(mapKey, mapValue);
      }
    } catch (SQLException sqle) {
      foreignKeys = null;
      sqle.printStackTrace();
    }
    return foreignKeys;
  }

  public String toString() {
    return name;
  }
} // end of JDatabase.java
