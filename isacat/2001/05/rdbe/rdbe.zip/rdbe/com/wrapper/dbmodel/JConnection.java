// start of JConnection.java
package com.wrapper.dbmodel;

import java.util.Map;
import java.util.Hashtable;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Statement;
import com.hp.hpl.mesa.rdf.jena.model.Resource;
import com.hp.hpl.mesa.rdf.jena.model.StmtIterator;

import com.wrapper.vocabulary.RDBE;

public class JConnection {

  public JConnection() {
  }

  public Connection getConnection(Model model, String connectionName) {
      String driver = null;
      String connUrl = null;
      String login = null; 
      String password = null;
      
    try{
      Resource connResource = model.getResource(connectionName);
       driver    = connResource.getProperty(RDBE.driver).getString();
   connUrl = connResource.getProperty(RDBE.connUrl).getString();
login = connResource.getProperty(RDBE.login).getString();
 password = connResource.getProperty(RDBE.password).getString();
    }catch(Exception e){
        e.printStackTrace();
    }
    
    Connection connection = null;
    try {
      Class.forName(driver);
      connection = DriverManager.getConnection(connUrl, login, password);
    } catch (SQLException sqle) {
      sqle.printStackTrace();
    } catch (ClassNotFoundException cnfe) {
      cnfe.printStackTrace();
    }
    return connection;
  }
}// end of JConnection.java
