// start of JDataset.java
package com.wrapper.dbmodel;

abstract class JDataset {

  protected JDatabase database = null;
  protected String name = null;


  public JDataset(JDatabase database, String name) {
    this.database = database;
    this.name = name;
  }

  private JDataset() {
  }

  public String getName() {
    return name;
  }

  public String toString() {
    return name;
  }
}// end of JDataset.java
