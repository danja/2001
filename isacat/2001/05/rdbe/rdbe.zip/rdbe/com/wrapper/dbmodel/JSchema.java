// start of JSchema.java
package com.wrapper.dbmodel;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;

import com.hp.hpl.mesa.rdf.jena.vocabulary.RDF;

import com.wrapper.vocabulary.RDBE;

public class JSchema extends JDataset {

  Resource resource = null;

  public JSchema(JDatabase database, String name) {
    super(database, name);
  }

  public Resource asResource(Model model) {
    if (resource != null) {
      return resource;
    }

    try {
      resource = model.createResource(database.getBaseUri()+"schema." + name);
      resource.addProperty(RDF.type, RDBE.Schema);
      resource.addProperty(RDBE.name, name);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return resource;
  }
}// end of JSchema.java
