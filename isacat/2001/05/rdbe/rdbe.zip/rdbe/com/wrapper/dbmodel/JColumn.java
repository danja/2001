// start of JColumn.java
package com.wrapper.dbmodel;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;

import com.hp.hpl.mesa.rdf.jena.vocabulary.RDF;

import com.wrapper.vocabulary.RDBE;

public class JColumn extends JDataset {

  Resource resource = null;
  private String key = "none";
  private String type = "unknown";
  private int size = -1;
  private String tableName = "unknown";

  public JColumn(JDatabase database, String name) {
    super(database, name);
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public void setType(String type) {
    this.type = type;
  }

  public void setColumnSize(int size) {
    this.size = size;
  }

  public String getTableName() {
    return tableName;
  }

  public String getKey() {
    return key;
  }

  public String getType() {
    return type;
  }

  public int getColumnSize() {
    return size;
  }

  public Resource asResource(Model model) {
    if (resource != null) {
      return resource;
    }
    try {
      resource = model.createResource(database.getBaseUri()+"column." + tableName + "." + name);
      resource.addProperty(RDF.type, RDBE.Column);
      resource.addProperty(RDBE.name, name);
      resource.addProperty(RDBE.columnType, type);
      resource.addProperty(RDBE.columnSize, size);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return resource;
  }
}// end of JColumn.java
