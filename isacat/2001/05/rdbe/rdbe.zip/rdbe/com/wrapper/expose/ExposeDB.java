// start of ExposeDB.java

package com.wrapper.expose;

import java.util.Hashtable;
import java.util.Map;

import java.util.List;
import java.util.Vector;
import java.util.Iterator;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

import com.wrapper.dbmodel.*;
import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Statement;

import com.hp.hpl.mesa.rdf.jena.model.StmtIterator;
import com.hp.hpl.mesa.rdf.jena.mem.ModelMem;
import com.hp.hpl.mesa.rdf.jena.model.Resource;

import com.hp.hpl.mesa.rdf.jena.vocabulary.RDF;

import com.wrapper.vocabulary.RDBE;
import com.wrapper.vocabulary.Admin;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    15 May 2001
 */
public class ExposeDB {

  Model model = new ModelMem();
  JDatabase database = null;
  Resource dbResource = null;
  String[] tableTypes = {"TABLE"};
  String baseUri;

  public ExposeDB(String[] args) {

    String sourceFile = args[0];
    String outputFile = args[1];
    String databaseName = args[2];
    String schemaName = args[3];
    String catalogName = args[4];
    String connectionName = args[5];

    // "c:/Program Files/Protege-2000/source.rdf" "c:/Program Files/Protege-2000/output.rdf" mydatabase wrox simple myconnection
    try {
      model.read(new FileReader(sourceFile), "");

      JConnection dbConnection = new JConnection();
      Connection connection = dbConnection.getConnection(model, connectionName);
      database = new JDatabase();
      database.setConnection(connection);

      baseUri = getBaseUri(databaseName);
      database.setBaseUri(baseUri);
      JSchema schema = database.getSchema(schemaName);
      
        if(schema == null) schema = new JSchema(database, "%"); // ***V2
      
      JCatalog catalog = database.getCatalog(catalogName);
// System.out.println("\n\n\n"+schema+"---"+catalog);
       

      dbResource = model.getResource(databaseName);
      addToModel(schema, catalog);
      model.write(new PrintWriter(System.out));

      model.write(new PrintWriter(new FileOutputStream(outputFile)));

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void addStaticMetadata(){
      try{
     model.createResource("")
                .addProperty(Admin.errorReportsTo, "mailto:danny_ayers@yahoo.co.uk")
                .addProperty(Admin.generatorAgent, "RDBE v0.2")
                .addProperty(Admin.prefix, "rdbe");
      }
      catch(Exception e){
          e.printStackTrace();
      }
  }
  
  private String getBaseUri(String databaseName){
          try{
      Resource resource= model.getResource(databaseName);
      baseUri = resource.getProperty(RDBE.baseUri).getString();
      }
      catch(Exception e){
          e.printStackTrace();
      }  
      System.out.println("BASEURI------------------- "+baseUri);
      return baseUri;
  }
       
       
  private void addToModel(JSchema schema, JCatalog catalog) throws Exception {
      addStaticMetadata();
    dbResource.addProperty(RDBE.contains, schema.asResource(model));
    addCatalogToModel(schema, catalog);
  }

  private void addCatalogToModel(JSchema schema, JCatalog catalog) throws Exception {
    schema.asResource(model).addProperty(RDBE.contains, catalog.asResource(model));
    addTablesToModel(catalog);
  }

  private void addTablesToModel(JCatalog catalog) throws Exception {

    List tables = database.getTables(catalog.getName(), "%", "%", tableTypes);

    if (tables == null) {
      throw new Exception("No tables found.");
    }
    Vector rdfTables = new Vector();

    Resource tableResource;
    JTable table;

    for (Iterator i = tables.iterator(); i.hasNext(); ) {
      table = (JTable) i.next();
      addColumnsToModel(table);
      catalog.asResource(model).addProperty(RDBE.contains, table.asResource(model));
    }
  }

  private void addColumnsToModel(JTable table) throws Exception {
    List columns = table.getColumns();
    JColumn column;
    for (Iterator i = columns.iterator(); i.hasNext(); ) {
      column = (JColumn) i.next();
      column.asResource(model).addProperty(RDBE.isKey, column.getKey());
      table.asResource(model).addProperty(RDBE.contains, column.asResource(model));
    }
  }

  public static void main(String[] args) {
    new ExposeDB(args);
  }
}// end of ExposeDB.java

