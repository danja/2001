// start of Admin.java
package com.wrapper.vocabulary;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;
import com.hp.hpl.mesa.rdf.jena.model.Property;
import com.hp.hpl.mesa.rdf.jena.model.RDFException;

import com.hp.hpl.mesa.rdf.jena.common.ErrorHelper;
import com.hp.hpl.mesa.rdf.jena.common.PropertyImpl;
import com.hp.hpl.mesa.rdf.jena.common.ResourceImpl;

public class Admin {

  public static Property errorReportsTo = null;
  public static Property generatorAgent = null;
  public static Property prefix = null;

  // namespace of this vocabulary
  protected final static String uri =
    "http://webns.net/mvcb#";
  
  // Properties
  final static String nerrorReportsTo = "errorReportsTo";
  final static String ngeneratorAgent = "generatorAgent";
  final static String nprefix = "prefix";

  public static String getURI() {
    return uri;
  }

  static {
    try {
      errorReportsTo = new PropertyImpl(uri, nerrorReportsTo);
      generatorAgent = new PropertyImpl(uri, ngeneratorAgent);
      prefix = new PropertyImpl(uri, nprefix);

    } catch (RDFException e) {
e.printStackTrace();
    }
  }
}// end of Admin.java

