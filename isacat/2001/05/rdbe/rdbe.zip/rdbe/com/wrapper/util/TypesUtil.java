
package com.wrapper.util;

import java.sql.Types;

/**
 *  Description of the Class
 *
 * @author     Danny Ayers
 * @created    15 May 2001
 */
public class TypesUtil {

  public static String getTypeAsString(int type) {
    switch (type) {
      case Types.ARRAY:
        return "ARRAY";
      case Types.BIGINT:
        return "BIGINT";
      case Types.BINARY:
        return "BINARY";
      case Types.BIT:
        return "BIT";
      case Types.BLOB:
        return "BLOB";
      case Types.CHAR:
        return "CHAR";
      case Types.CLOB:
        return "CLOB";
      case Types.DATE:
        return "DATE";
      case Types.DECIMAL:
        return "DECIMAL";
      case Types.DISTINCT:
        return "DISTINCT";
      case Types.DOUBLE:
        return "DOUBLE";
      case Types.FLOAT:
        return "FLOAT";
      case Types.INTEGER:
        return "INTEGER";
      case Types.JAVA_OBJECT:
        return "JAVA_OBJECT";
      case Types.LONGVARBINARY:
        return "LONGVARBINARY";
      case Types.NULL:
        return "NULL";
      case Types.NUMERIC:
        return "NUMERIC";
      case Types.OTHER:
        return "OTHER";
      case Types.REAL:
        return "REAL";
      case Types.REF:
        return "REF";
      case Types.SMALLINT:
        return "SMALLINT";
      case Types.STRUCT:
        return "STRUCT";
      case Types.TIME:
        return "TIME";
      case Types.TIMESTAMP:
        return "TIMESTAMP";
      case Types.TINYINT:
        return "TINYINT";
      case Types.VARBINARY:
        return "VARBINARY";
      case Types.VARCHAR:
        return "VARCHAR";
    }
    return "UNKNOWN";
  }
}
