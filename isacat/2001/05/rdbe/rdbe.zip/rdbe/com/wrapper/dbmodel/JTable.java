// start of JTable.java

package com.wrapper.dbmodel;

import java.util.List;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;

import com.hp.hpl.mesa.rdf.jena.vocabulary.RDF;

import com.wrapper.vocabulary.RDBE;

public class JTable extends JDataset {

  Resource resource = null;
  String catalogName = "%";
  String schemaName = "%";
  String type = null;

  public JTable(JDatabase database, String name) {
    super(database, name);
  }

  public void setCatalogName(String catalogName) {
    this.catalogName = catalogName;
  }

  public void setSchemaName(String schemaName) {
    this.schemaName = schemaName;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getCatalogName() {
    return catalogName;
  }

  public String getSchemaName() {
    return schemaName;
  }

  public String getType() {
    return type;
  }

  public List getColumns() {
    // String catalog, String schemaPattern, String tablePattern, String columnPattern
    return database.getColumns(catalogName, schemaName, name, "%");
  }

  public Resource asResource(Model model) {
    if (resource != null) {
      return resource;
    }

    try {
      resource = model.createResource(database.getBaseUri()+"table." + name);
      resource.addProperty(RDF.type, RDBE.Table);
      resource.addProperty(RDBE.name, name);
      resource.addProperty(RDBE.tableType, type);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return resource;
  }
}// end of JTable.java
