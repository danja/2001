// start of RDBE.java
package com.wrapper.vocabulary;

import com.hp.hpl.mesa.rdf.jena.model.Model;
import com.hp.hpl.mesa.rdf.jena.model.Resource;
import com.hp.hpl.mesa.rdf.jena.model.Property;
import com.hp.hpl.mesa.rdf.jena.model.RDFException;

import com.hp.hpl.mesa.rdf.jena.common.ErrorHelper;
import com.hp.hpl.mesa.rdf.jena.common.PropertyImpl;
import com.hp.hpl.mesa.rdf.jena.common.ResourceImpl;

public class RDBE {

    // resources
  public static Resource DBResource = null;
  public static Resource Database = null;
  public static Resource Dataset = null;
  public static Resource Connection = null;
  public static Resource DBCParameter = null;
  public static Resource Catalog = null;
  public static Resource Schema = null;
  public static Resource Table = null;
  public static Resource Column = null;
  public static Resource Key = null;

  // properties
  public static Property name = null;
  public static Property description = null;

  // Dataset property
  public static Property contains = null;

  // Connection properties
  public static Property driver = null;
  public static Property connUrl = null;
  public static Property login = null;
  public static Property password = null;

  // Database properties
  public static Property baseUri = null;
  public static Property xsdUrl = null;
  public static Property queryUrl = null;

  // Table property
  public static Property tableType = null;

  // Column properties
  public static Property isKey = null;
  public static Property columnType = null;
  public static Property columnSize = null;

  // namespace of this vocabulary
  protected final static String uri =
    "http://www.isacat.net/ns/rdbe#";

  // Resources
  final static String nDBResource = "DBResource";
  final static String nDatabase = "Database";
  final static String nDataset = "Dataset";
  final static String nConnection = "Connection";
  final static String nDBCParameter = "DBCParameter";
  final static String nCatalog = "Catalog";
  final static String nSchema = "Schema";
  final static String nTable = "Table";
  final static String nColumn = "Column";
  final static String nKey = "Key";

  // Properties
  final static String nname = "name";
  final static String ndescription = "description";

  final static String ndriver = "driver";
  final static String nconnUrl = "connUrl";
  final static String nlogin = "login";
  final static String npassword = "password";

  final static String nbaseUri = "baseUri";  
  final static String nxsdUrl = "xsdUrl";
  final static String nqueryUrl = "queryUrl";
  final static String ntableType = "tableType";

  final static String ncontains = "contains";
  final static String nisKey = "isKey";
  final static String ncolumnType = "columnType";
  final static String ncolumnSize = "columnSize";

  public static String getURI() {
    return uri;
  }

  static {
    try {
      DBResource = new ResourceImpl(uri + nDBResource);
      Database = new ResourceImpl(uri + nDatabase);
      Dataset = new ResourceImpl(uri + nDataset);
      Connection = new ResourceImpl(uri + nConnection);
      DBCParameter = new ResourceImpl(uri + nDBCParameter);
      Table = new ResourceImpl(uri + nTable);
      Catalog = new ResourceImpl(uri + nCatalog);
      Schema = new ResourceImpl(uri + nSchema);
      Column = new ResourceImpl(uri + nColumn);
      Key = new ResourceImpl(uri + nKey);

      name = new PropertyImpl(uri, nname);
      description = new PropertyImpl(uri, ndescription);

      driver = new PropertyImpl(uri, ndriver);
      connUrl = new PropertyImpl(uri, nconnUrl);
      login = new PropertyImpl(uri, nlogin);
      password = new PropertyImpl(uri, npassword);

      baseUri = new PropertyImpl(uri, nbaseUri);

      xsdUrl = new PropertyImpl(uri, nxsdUrl);
      queryUrl = new PropertyImpl(uri, nqueryUrl);

      tableType = new PropertyImpl(uri, ntableType);
      contains = new PropertyImpl(uri, ncontains);

      columnSize = new PropertyImpl(uri, ncolumnSize);
      columnType = new PropertyImpl(uri, ncolumnType);
      isKey = new PropertyImpl(uri, nisKey);

    } catch (RDFException e) {
e.printStackTrace();
    }
  }
}// end of RDBE.java

